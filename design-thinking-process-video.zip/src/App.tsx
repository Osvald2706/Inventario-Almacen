import { useState } from 'react';
import { DataProvider, useData } from './context/DataContext';
import { LoginPage } from './components/LoginPage';
import { Sidebar } from './components/Sidebar';
import { Dashboard } from './components/Dashboard';
import { ArticlesPage } from './components/ArticlesPage';
import { MovementsPage } from './components/MovementsPage';
import { ProjectsPage } from './components/ProjectsPage';
import { UsersPage } from './components/UsersPage';
import { ReportsPage } from './components/ReportsPage';
import { LogsPage } from './components/LogsPage';
import { Bell, Search, Menu, X, Warehouse } from 'lucide-react';
import type { Page } from './types';

function AppContent() {
  const { currentUser, logout } = useData();
  const [currentPage, setCurrentPage] = useState<Page>('dashboard');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  if (!currentUser) {
    return <LoginPage />;
  }

  const pageComponents: Record<Page, React.ReactNode> = {
    dashboard: <Dashboard />,
    articles: <ArticlesPage />,
    movements: <MovementsPage />,
    projects: <ProjectsPage />,
    users: <UsersPage />,
    reports: <ReportsPage />,
    logs: <LogsPage />,
  };

  const pageTitles: Record<Page, string> = {
    dashboard: 'Dashboard',
    articles: 'Artículos',
    movements: 'Movimientos',
    projects: 'Proyectos',
    users: 'Usuarios',
    reports: 'Reportes',
    logs: 'Bitácora',
  };

  const handleNavigate = (page: Page) => {
    setCurrentPage(page);
    setMobileMenuOpen(false);
  };

  const roleColors: Record<string, string> = {
    administrador: 'from-red-500 to-rose-600',
    supervisor: 'from-purple-500 to-violet-600',
    almacén: 'from-blue-500 to-indigo-600',
    consulta: 'from-slate-500 to-slate-600',
  };

  return (
    <div className="min-h-screen bg-slate-100">
      {/* Desktop Sidebar */}
      <div className="hidden lg:block">
        <Sidebar currentPage={currentPage} onNavigate={handleNavigate} collapsed={sidebarCollapsed} onToggle={() => setSidebarCollapsed(!sidebarCollapsed)} />
      </div>

      {/* Mobile Menu Overlay */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-black/50" onClick={() => setMobileMenuOpen(false)} />
          <div className="relative z-10">
            <Sidebar currentPage={currentPage} onNavigate={handleNavigate} collapsed={false} onToggle={() => setMobileMenuOpen(false)} />
          </div>
        </div>
      )}

      {/* Main Content */}
      <div className={`transition-all duration-300 ${sidebarCollapsed ? 'lg:ml-[72px]' : 'lg:ml-64'}`}>
        {/* Top Bar */}
        <header className="sticky top-0 z-30 bg-white/80 backdrop-blur-xl border-b border-slate-200">
          <div className="flex items-center justify-between h-16 px-4 sm:px-6 lg:px-8">
            <div className="flex items-center gap-3">
              <button onClick={() => setMobileMenuOpen(true)} className="lg:hidden p-2 hover:bg-slate-100 rounded-xl cursor-pointer">
                {mobileMenuOpen ? <X className="w-5 h-5 text-slate-600" /> : <Menu className="w-5 h-5 text-slate-600" />}
              </button>
              <div className="lg:hidden flex items-center gap-2">
                <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-cyan-400 rounded-lg flex items-center justify-center">
                  <Warehouse className="w-4 h-4 text-white" />
                </div>
                <span className="font-bold text-slate-900 text-sm">InventarioPro</span>
              </div>
              <div className="hidden lg:block">
                <h2 className="font-semibold text-slate-800">{pageTitles[currentPage]}</h2>
              </div>
            </div>

            <div className="flex items-center gap-2 sm:gap-4">
              <div className="hidden sm:block relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input type="text" placeholder="Buscar..." className="w-48 md:w-64 pl-10 pr-4 py-2 bg-slate-100 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:bg-white transition-all" />
              </div>

              <button className="relative p-2.5 hover:bg-slate-100 rounded-xl cursor-pointer transition-colors">
                <Bell className="w-5 h-5 text-slate-500" />
                <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full ring-2 ring-white" />
              </button>

              <div className="flex items-center gap-2 pl-2 sm:pl-4 border-l border-slate-200">
                <div className={`w-9 h-9 bg-gradient-to-br ${roleColors[currentUser.role] || 'from-blue-500 to-indigo-600'} rounded-xl flex items-center justify-center text-white font-bold text-sm shadow-lg`}>
                  {currentUser.avatar}
                </div>
                <div className="hidden md:block">
                  <div className="text-sm font-semibold text-slate-800 leading-tight">{currentUser.name}</div>
                  <div className="text-[10px] text-slate-400 font-medium capitalize">{currentUser.role}</div>
                </div>
                <button onClick={logout} className="hidden md:block ml-2 text-xs text-slate-400 hover:text-red-500 cursor-pointer transition-colors" title="Cerrar sesión">
                  Salir
                </button>
              </div>
            </div>
          </div>
        </header>

        {/* Page Content */}
        <main className="p-4 sm:p-6 lg:p-8">
          {pageComponents[currentPage]}
        </main>

        {/* Footer */}
        <footer className="border-t border-slate-200 bg-white px-6 py-4 mt-8">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-slate-400">
            <span>© 2025 InventarioPro — Sistema de Gestión de Inventarios v1.0</span>
            <span>Sesión: {currentUser.name} ({currentUser.role})</span>
          </div>
        </footer>
      </div>
    </div>
  );
}

export function App() {
  return (
    <DataProvider>
      <AppContent />
    </DataProvider>
  );
}
