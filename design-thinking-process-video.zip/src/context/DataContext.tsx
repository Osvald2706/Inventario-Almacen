import { createContext, useContext, useState, useCallback, type ReactNode } from 'react';
import type { Article, Movement, Project, User, ActivityLog } from '../types';

interface DataContextType {
  // Auth
  currentUser: User | null;
  login: (email: string, password: string) => boolean;
  logout: () => void;

  // Articles
  articles: Article[];
  addArticle: (article: Omit<Article, 'id' | 'createdAt' | 'updatedAt'>) => void;
  deleteArticle: (id: string) => void;

  // Movements
  movements: Movement[];
  addMovement: (movement: Omit<Movement, 'id'>) => void;
  deleteMovement: (id: string) => void;

  // Projects
  projects: Project[];
  addProject: (project: Omit<Project, 'id'>) => void;
  deleteProject: (id: string) => void;

  // Users
  users: User[];
  addUser: (user: Omit<User, 'id'>) => void;
  deleteUser: (id: string) => void;

  // Logs
  logs: ActivityLog[];
  addLog: (action: string, detail: string) => void;
}

const DataContext = createContext<DataContextType | null>(null);

export function useData() {
  const ctx = useContext(DataContext);
  if (!ctx) throw new Error('useData must be used within DataProvider');
  return ctx;
}

const initialUsers: User[] = [
  { id: 'u1', name: 'Administrador General', email: 'admin@inventariopro.com', password: 'admin123', role: 'administrador', avatar: 'AG', active: true, lastLogin: '2025-06-18T08:00:00Z' },
  { id: 'u2', name: 'María González', email: 'maria.gonzalez@empresa.com', password: 'maria123', role: 'supervisor', avatar: 'MG', active: true, lastLogin: '2025-06-18T07:45:00Z' },
  { id: 'u3', name: 'Carlos Méndez', email: 'carlos.mendez@empresa.com', password: 'carlos123', role: 'almacén', avatar: 'CM', active: true, lastLogin: '2025-06-18T07:30:00Z' },
  { id: 'u4', name: 'Ana Luisa Torres', email: 'ana.torres@empresa.com', password: 'ana123', role: 'almacén', avatar: 'AT', active: true, lastLogin: '2025-06-17T14:00:00Z' },
  { id: 'u5', name: 'Ing. Patricia Solis', email: 'patricia.solis@empresa.com', password: 'patricia123', role: 'supervisor', avatar: 'PS', active: true, lastLogin: '2025-06-16T10:00:00Z' },
  { id: 'u6', name: 'Luis Hernández', email: 'luis.hernandez@empresa.com', password: 'luis123', role: 'consulta', avatar: 'LH', active: false, lastLogin: '2025-05-20T09:00:00Z' },
];

const initialArticles: Article[] = [
  { id: 'a1', code: 'HER-001', name: 'Taladro Percutor DeWalt 20V', category: 'herramienta', unit: 'pza', quantity: 5, minStock: 2, location: 'Rack A-01', status: 'nuevo', observations: 'Con estuche y brocas incluidas', createdAt: '2025-01-15T08:00:00Z', updatedAt: '2025-06-10T14:30:00Z' },
  { id: 'a2', code: 'MAT-015', name: 'Cemento Portland Gris 50kg', category: 'material', unit: 'bolsa', quantity: 120, minStock: 50, location: 'Zona B-03', status: 'nuevo', observations: 'Marca CEMEX', createdAt: '2025-02-01T09:00:00Z', updatedAt: '2025-06-18T10:00:00Z' },
  { id: 'a3', code: 'REF-008', name: 'Balero 6205-2RS SKF', category: 'refacción', unit: 'pza', quantity: 8, minStock: 10, location: 'Rack C-12', status: 'nuevo', observations: 'Para motor bomba principal', createdAt: '2025-01-20T11:00:00Z', updatedAt: '2025-06-15T16:00:00Z' },
  { id: 'a4', code: 'CON-022', name: 'Disco de Corte 4½" Norton', category: 'consumible', unit: 'pza', quantity: 45, minStock: 20, location: 'Rack A-05', status: 'nuevo', observations: '', createdAt: '2025-03-10T07:00:00Z', updatedAt: '2025-06-17T09:00:00Z' },
  { id: 'a5', code: 'EPP-003', name: 'Casco de Seguridad 3M H-700', category: 'EPP', unit: 'pza', quantity: 15, minStock: 10, location: 'Rack D-01', status: 'nuevo', observations: 'Color blanco, ajuste tipo matraca', createdAt: '2025-01-05T10:00:00Z', updatedAt: '2025-06-12T08:00:00Z' },
  { id: 'a6', code: 'ELE-011', name: 'Cable THW Cal. 12 Condumex', category: 'eléctrico', unit: 'rollo', quantity: 3, minStock: 5, location: 'Rack E-02', status: 'nuevo', observations: 'Rollo de 100m, color rojo', createdAt: '2025-02-14T13:00:00Z', updatedAt: '2025-06-16T11:00:00Z' },
  { id: 'a7', code: 'HER-025', name: 'Esmeriladora Angular Makita 9557', category: 'herramienta', unit: 'pza', quantity: 3, minStock: 2, location: 'Rack A-02', status: 'usado', observations: 'Una unidad requiere cambio de carbones', createdAt: '2025-01-10T09:30:00Z', updatedAt: '2025-06-14T15:00:00Z' },
  { id: 'a8', code: 'MAT-032', name: 'Varilla Corrugada 3/8" 12m', category: 'material', unit: 'pza', quantity: 200, minStock: 100, location: 'Patio F-01', status: 'nuevo', observations: 'Grado 42', createdAt: '2025-03-01T08:00:00Z', updatedAt: '2025-06-18T07:00:00Z' },
  { id: 'a9', code: 'CON-045', name: 'Electrodo 6013 3/32" Lincoln', category: 'consumible', unit: 'kg', quantity: 2, minStock: 5, location: 'Rack A-08', status: 'nuevo', observations: 'Mantener en lugar seco', createdAt: '2025-04-01T10:00:00Z', updatedAt: '2025-06-17T14:00:00Z' },
  { id: 'a10', code: 'EQU-007', name: 'Compresor de Aire 50L Truper', category: 'equipo', unit: 'pza', quantity: 1, minStock: 1, location: 'Taller G-01', status: 'usado', observations: 'Mantenimiento programado julio 2025', createdAt: '2024-11-20T09:00:00Z', updatedAt: '2025-06-10T12:00:00Z' },
  { id: 'a11', code: 'HER-040', name: 'Nivel Láser Bosch GLL 3-80', category: 'herramienta', unit: 'pza', quantity: 2, minStock: 1, location: 'Rack A-03', status: 'nuevo', observations: 'Con trípode y estuche', createdAt: '2025-05-01T08:00:00Z', updatedAt: '2025-06-11T10:00:00Z' },
  { id: 'a12', code: 'MAT-050', name: 'Tubo PVC Hidráulico 2" 6m', category: 'material', unit: 'pza', quantity: 0, minStock: 15, location: 'Patio F-03', status: 'nuevo', observations: 'AGOTADO - Solicitar compra urgente', createdAt: '2025-03-15T09:00:00Z', updatedAt: '2025-06-18T16:00:00Z' },
  { id: 'a13', code: 'EPP-010', name: 'Guantes de Carnaza Reforzados', category: 'EPP', unit: 'par', quantity: 22, minStock: 15, location: 'Rack D-02', status: 'nuevo', observations: 'Talla universal', createdAt: '2025-02-20T07:30:00Z', updatedAt: '2025-06-13T09:00:00Z' },
  { id: 'a14', code: 'REF-020', name: 'Banda V A-68 Gates', category: 'refacción', unit: 'pza', quantity: 4, minStock: 3, location: 'Rack C-15', status: 'nuevo', observations: 'Para compresor principal', createdAt: '2025-04-10T11:00:00Z', updatedAt: '2025-06-16T13:00:00Z' },
  { id: 'a15', code: 'HER-055', name: 'Llave Stillson 18" Ridgid', category: 'herramienta', unit: 'pza', quantity: 1, minStock: 2, location: 'Rack A-04', status: 'dañado', observations: 'Mordaza desgastada, requiere reemplazo', createdAt: '2024-10-01T08:00:00Z', updatedAt: '2025-06-14T10:00:00Z' },
];

const initialProjects: Project[] = [
  { id: 'p1', code: 'PROY-2025-001', name: 'Nave Industrial Querétaro', client: 'Grupo Aceros del Norte', startDate: '2025-01-15', endDate: '2025-08-30', status: 'activo', modules: [
    { id: 'm1', name: 'Cimentación', projectId: 'p1' },
    { id: 'm2', name: 'Estructura Metálica', projectId: 'p1' },
    { id: 'm3', name: 'Instalación Eléctrica', projectId: 'p1' },
    { id: 'm4', name: 'Acabados', projectId: 'p1' },
  ]},
  { id: 'p2', code: 'PROY-2025-002', name: 'Remodelación Oficinas CDMX', client: 'Tech Solutions SA de CV', startDate: '2025-03-01', endDate: '2025-06-30', status: 'activo', modules: [
    { id: 'm5', name: 'Demolición', projectId: 'p2' },
    { id: 'm6', name: 'Obra Civil', projectId: 'p2' },
    { id: 'm7', name: 'Instalaciones', projectId: 'p2' },
    { id: 'm8', name: 'Acabados y Pintura', projectId: 'p2' },
  ]},
  { id: 'p3', code: 'PROY-2024-015', name: 'Planta de Tratamiento Monterrey', client: 'AguaPura SA', startDate: '2024-06-01', endDate: '2025-02-28', status: 'cerrado', modules: [
    { id: 'm9', name: 'Obra Civil', projectId: 'p3' },
    { id: 'm10', name: 'Instalación Mecánica', projectId: 'p3' },
    { id: 'm11', name: 'Puesta en Marcha', projectId: 'p3' },
  ]},
  { id: 'p4', code: 'PROY-2025-003', name: 'Almacén Logístico Guadalajara', client: 'LogiMex SA de CV', startDate: '2025-05-15', endDate: '2025-12-15', status: 'activo', modules: [
    { id: 'm12', name: 'Terracerías', projectId: 'p4' },
    { id: 'm13', name: 'Cimentación', projectId: 'p4' },
    { id: 'm14', name: 'Estructura', projectId: 'p4' },
  ]},
];

const initialMovements: Movement[] = [
  { id: 'mv1', articleId: 'a2', articleName: 'Cemento Portland Gris 50kg', articleCode: 'MAT-015', type: 'salida', quantity: 30, date: '2025-06-18T08:15:00Z', reason: 'Uso en proyecto', userId: 'u3', userName: 'Carlos Méndez', projectId: 'p1', projectName: 'Nave Industrial Querétaro', moduleId: 'm1', moduleName: 'Cimentación', authorizedBy: 'Administrador General', observations: 'Para colado de zapatas' },
  { id: 'mv2', articleId: 'a4', articleName: 'Disco de Corte 4½" Norton', articleCode: 'CON-022', type: 'salida', quantity: 10, date: '2025-06-17T14:30:00Z', reason: 'Uso en proyecto', userId: 'u3', userName: 'Carlos Méndez', projectId: 'p1', projectName: 'Nave Industrial Querétaro', moduleId: 'm2', moduleName: 'Estructura Metálica', authorizedBy: 'Administrador General', observations: '' },
  { id: 'mv3', articleId: 'a1', articleName: 'Taladro Percutor DeWalt 20V', articleCode: 'HER-001', type: 'salida', quantity: 2, date: '2025-06-17T09:00:00Z', reason: 'Uso en proyecto', userId: 'u4', userName: 'Ana Luisa Torres', projectId: 'p2', projectName: 'Remodelación Oficinas CDMX', moduleId: 'm6', moduleName: 'Obra Civil', authorizedBy: 'Ing. Patricia Solis', observations: 'Préstamo temporal' },
  { id: 'mv4', articleId: 'a6', articleName: 'Cable THW Cal. 12 Condumex', articleCode: 'ELE-011', type: 'salida', quantity: 2, date: '2025-06-16T11:00:00Z', reason: 'Uso en proyecto', userId: 'u3', userName: 'Carlos Méndez', projectId: 'p2', projectName: 'Remodelación Oficinas CDMX', moduleId: 'm7', moduleName: 'Instalaciones', authorizedBy: 'Ing. Patricia Solis', observations: '' },
  { id: 'mv5', articleId: 'a2', articleName: 'Cemento Portland Gris 50kg', articleCode: 'MAT-015', type: 'entrada', quantity: 100, date: '2025-06-15T07:30:00Z', reason: 'compra', userId: 'u2', userName: 'María González', observations: 'OC-2025-0456, Proveedor: CEMEX' },
  { id: 'mv6', articleId: 'a8', articleName: 'Varilla Corrugada 3/8" 12m', articleCode: 'MAT-032', type: 'entrada', quantity: 150, date: '2025-06-14T08:00:00Z', reason: 'compra', userId: 'u2', userName: 'María González', observations: 'OC-2025-0449' },
  { id: 'mv7', articleId: 'a5', articleName: 'Casco de Seguridad 3M H-700', articleCode: 'EPP-003', type: 'salida', quantity: 5, date: '2025-06-14T10:00:00Z', reason: 'Uso en proyecto', userId: 'u3', userName: 'Carlos Méndez', projectId: 'p4', projectName: 'Almacén Logístico Guadalajara', moduleId: 'm12', moduleName: 'Terracerías', authorizedBy: 'Administrador General', observations: 'Para personal nuevo' },
  { id: 'mv8', articleId: 'a9', articleName: 'Electrodo 6013 3/32" Lincoln', articleCode: 'CON-045', type: 'salida', quantity: 8, date: '2025-06-13T15:00:00Z', reason: 'Uso en proyecto', userId: 'u4', userName: 'Ana Luisa Torres', projectId: 'p1', projectName: 'Nave Industrial Querétaro', moduleId: 'm2', moduleName: 'Estructura Metálica', authorizedBy: 'Administrador General', observations: '' },
  { id: 'mv9', articleId: 'a13', articleName: 'Guantes de Carnaza Reforzados', articleCode: 'EPP-010', type: 'salida', quantity: 8, date: '2025-06-12T09:30:00Z', reason: 'Uso en proyecto', userId: 'u3', userName: 'Carlos Méndez', projectId: 'p1', projectName: 'Nave Industrial Querétaro', moduleId: 'm2', moduleName: 'Estructura Metálica', authorizedBy: 'Administrador General', observations: '' },
  { id: 'mv10', articleId: 'a1', articleName: 'Taladro Percutor DeWalt 20V', articleCode: 'HER-001', type: 'entrada', quantity: 1, date: '2025-06-11T16:00:00Z', reason: 'devolución', userId: 'u4', userName: 'Ana Luisa Torres', observations: 'Devuelto del proyecto Monterrey' },
  { id: 'mv11', articleId: 'a12', articleName: 'Tubo PVC Hidráulico 2" 6m', articleCode: 'MAT-050', type: 'salida', quantity: 15, date: '2025-06-10T08:00:00Z', reason: 'Uso en proyecto', userId: 'u3', userName: 'Carlos Méndez', projectId: 'p2', projectName: 'Remodelación Oficinas CDMX', moduleId: 'm7', moduleName: 'Instalaciones', authorizedBy: 'Ing. Patricia Solis', observations: 'Se agotó existencia' },
  { id: 'mv12', articleId: 'a7', articleName: 'Esmeriladora Angular Makita 9557', articleCode: 'HER-025', type: 'salida', quantity: 1, date: '2025-06-09T10:00:00Z', reason: 'Uso en proyecto', userId: 'u4', userName: 'Ana Luisa Torres', projectId: 'p1', projectName: 'Nave Industrial Querétaro', moduleId: 'm2', moduleName: 'Estructura Metálica', authorizedBy: 'Administrador General', observations: '' },
];

const initialLogs: ActivityLog[] = [
  { id: 'l1', userId: 'u3', userName: 'Carlos Méndez', action: 'Salida registrada', detail: '30 bolsas de Cemento Portland → Nave Industrial Querétaro / Cimentación', timestamp: '2025-06-18T08:15:00Z' },
  { id: 'l2', userId: 'u3', userName: 'Carlos Méndez', action: 'Salida registrada', detail: '10 pzas de Disco de Corte → Nave Industrial Querétaro / Estructura Metálica', timestamp: '2025-06-17T14:30:00Z' },
  { id: 'l3', userId: 'u4', userName: 'Ana Luisa Torres', action: 'Salida registrada', detail: '2 pzas Taladro DeWalt → Remodelación Oficinas CDMX / Obra Civil', timestamp: '2025-06-17T09:00:00Z' },
  { id: 'l4', userId: 'u2', userName: 'María González', action: 'Entrada registrada', detail: '100 bolsas de Cemento Portland (Compra OC-2025-0456)', timestamp: '2025-06-15T07:30:00Z' },
  { id: 'l5', userId: 'u2', userName: 'María González', action: 'Entrada registrada', detail: '150 pzas Varilla Corrugada 3/8" (Compra OC-2025-0449)', timestamp: '2025-06-14T08:00:00Z' },
  { id: 'l6', userId: 'u1', userName: 'Administrador General', action: 'Artículo creado', detail: 'Nivel Láser Bosch GLL 3-80 (HER-040)', timestamp: '2025-05-01T08:00:00Z' },
  { id: 'l7', userId: 'u1', userName: 'Administrador General', action: 'Proyecto creado', detail: 'Almacén Logístico Guadalajara (PROY-2025-003)', timestamp: '2025-05-15T09:00:00Z' },
  { id: 'l8', userId: 'u2', userName: 'María González', action: 'Usuario desactivado', detail: 'Luis Hernández — Rol: consulta', timestamp: '2025-05-21T10:00:00Z' },
];

let _counter = 100;
function genId(prefix: string) { return `${prefix}${++_counter}`; }

export function DataProvider({ children }: { children: ReactNode }) {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [articles, setArticles] = useState<Article[]>(initialArticles);
  const [movements, setMovements] = useState<Movement[]>(initialMovements);
  const [projects, setProjects] = useState<Project[]>(initialProjects);
  const [users, setUsers] = useState<User[]>(initialUsers);
  const [logs, setLogs] = useState<ActivityLog[]>(initialLogs);

  const addLog = useCallback((action: string, detail: string) => {
    setLogs(prev => [{
      id: genId('l'),
      userId: currentUser?.id || 'system',
      userName: currentUser?.name || 'Sistema',
      action,
      detail,
      timestamp: new Date().toISOString(),
    }, ...prev]);
  }, [currentUser]);

  const login = useCallback((email: string, password: string): boolean => {
    const user = users.find(u => u.email.toLowerCase() === email.toLowerCase() && u.password === password && u.active);
    if (user) {
      setCurrentUser({ ...user, lastLogin: new Date().toISOString() });
      setUsers(prev => prev.map(u => u.id === user.id ? { ...u, lastLogin: new Date().toISOString() } : u));
      return true;
    }
    return false;
  }, [users]);

  const logout = useCallback(() => {
    setCurrentUser(null);
  }, []);

  // Articles
  const addArticle = useCallback((article: Omit<Article, 'id' | 'createdAt' | 'updatedAt'>) => {
    const now = new Date().toISOString();
    const newArticle: Article = { ...article, id: genId('a'), createdAt: now, updatedAt: now };
    setArticles(prev => [newArticle, ...prev]);
    addLog('Artículo creado', `${article.name} (${article.code})`);
  }, [addLog]);

  const deleteArticle = useCallback((id: string) => {
    const article = articles.find(a => a.id === id);
    setArticles(prev => prev.filter(a => a.id !== id));
    if (article) addLog('Artículo eliminado', `${article.name} (${article.code})`);
  }, [articles, addLog]);

  // Movements
  const addMovement = useCallback((movement: Omit<Movement, 'id'>) => {
    const newMov: Movement = { ...movement, id: genId('mv') };
    setMovements(prev => [newMov, ...prev]);
    // Update article quantity
    setArticles(prev => prev.map(a => {
      if (a.id === movement.articleId) {
        const newQty = movement.type === 'entrada' ? a.quantity + movement.quantity : Math.max(0, a.quantity - movement.quantity);
        return { ...a, quantity: newQty, updatedAt: new Date().toISOString() };
      }
      return a;
    }));
    addLog(movement.type === 'entrada' ? 'Entrada registrada' : 'Salida registrada',
      `${movement.quantity} ${movement.articleName}${movement.projectName ? ` → ${movement.projectName}` : ''}`);
  }, [addLog]);

  const deleteMovement = useCallback((id: string) => {
    const mv = movements.find(m => m.id === id);
    setMovements(prev => prev.filter(m => m.id !== id));
    if (mv) addLog('Movimiento eliminado', `${mv.type === 'entrada' ? 'Entrada' : 'Salida'}: ${mv.quantity} ${mv.articleName}`);
  }, [movements, addLog]);

  // Projects
  const addProject = useCallback((project: Omit<Project, 'id'>) => {
    const newProj: Project = { ...project, id: genId('p') };
    setProjects(prev => [newProj, ...prev]);
    addLog('Proyecto creado', `${project.name} (${project.code})`);
  }, [addLog]);

  const deleteProject = useCallback((id: string) => {
    const project = projects.find(p => p.id === id);
    setProjects(prev => prev.filter(p => p.id !== id));
    if (project) addLog('Proyecto eliminado', `${project.name} (${project.code})`);
  }, [projects, addLog]);

  // Users
  const addUser = useCallback((user: Omit<User, 'id'>) => {
    const newUser: User = { ...user, id: genId('u') };
    setUsers(prev => [newUser, ...prev]);
    addLog('Usuario creado', `${user.name} — Rol: ${user.role}`);
  }, [addLog]);

  const deleteUser = useCallback((id: string) => {
    if (id === currentUser?.id) return; // Can't delete yourself
    const user = users.find(u => u.id === id);
    setUsers(prev => prev.filter(u => u.id !== id));
    if (user) addLog('Usuario eliminado', `${user.name} (${user.email})`);
  }, [users, currentUser, addLog]);

  return (
    <DataContext.Provider value={{
      currentUser, login, logout,
      articles, addArticle, deleteArticle,
      movements, addMovement, deleteMovement,
      projects, addProject, deleteProject,
      users, addUser, deleteUser,
      logs, addLog,
    }}>
      {children}
    </DataContext.Provider>
  );
}
