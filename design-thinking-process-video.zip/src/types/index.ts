export type ArticleStatus = 'nuevo' | 'usado' | 'dañado' | 'obsoleto';
export type UnitOfMeasure = 'pza' | 'kg' | 'lt' | 'mt' | 'caja' | 'rollo' | 'juego' | 'par' | 'bolsa' | 'galón';
export type ArticleCategory = 'herramienta' | 'material' | 'refacción' | 'consumible' | 'equipo' | 'EPP' | 'eléctrico' | 'otro';
export type MovementType = 'entrada' | 'salida';
export type EntryReason = 'compra' | 'devolución' | 'ajuste' | 'transferencia' | 'donación';
export type ProjectStatus = 'activo' | 'cerrado' | 'pausado';
export type UserRole = 'administrador' | 'supervisor' | 'almacén' | 'consulta';

export interface Article {
  id: string;
  code: string;
  name: string;
  category: ArticleCategory;
  unit: UnitOfMeasure;
  quantity: number;
  minStock: number;
  location: string;
  status: ArticleStatus;
  observations: string;
  imageUrl?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Movement {
  id: string;
  articleId: string;
  articleName: string;
  articleCode: string;
  type: MovementType;
  quantity: number;
  date: string;
  reason: EntryReason | string;
  userId: string;
  userName: string;
  projectId?: string;
  projectName?: string;
  moduleId?: string;
  moduleName?: string;
  authorizedBy?: string;
  observations: string;
}

export interface Project {
  id: string;
  code: string;
  name: string;
  client: string;
  startDate: string;
  endDate: string;
  status: ProjectStatus;
  modules: ProjectModule[];
}

export interface ProjectModule {
  id: string;
  name: string;
  projectId: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  password: string;
  role: UserRole;
  avatar: string;
  active: boolean;
  lastLogin: string;
}

export interface ActivityLog {
  id: string;
  userId: string;
  userName: string;
  action: string;
  detail: string;
  timestamp: string;
}

export type Page = 'dashboard' | 'articles' | 'movements' | 'projects' | 'users' | 'reports' | 'logs';
