import { useState } from 'react';
import { Warehouse, Eye, EyeOff, LogIn, AlertCircle, Shield } from 'lucide-react';
import { useData } from '../context/DataContext';

export function LoginPage() {
  const { login } = useData();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (!email.trim() || !password.trim()) {
      setError('Por favor ingresa tu correo y contraseña');
      return;
    }
    setLoading(true);
    setTimeout(() => {
      const success = login(email, password);
      if (!success) {
        setError('Correo o contraseña incorrectos, o el usuario está inactivo');
      }
      setLoading(false);
    }, 800);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-950 to-slate-900 flex items-center justify-center p-4">
      {/* Background pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-20 left-20 w-72 h-72 bg-blue-400 rounded-full blur-3xl" />
        <div className="absolute bottom-20 right-20 w-96 h-96 bg-cyan-400 rounded-full blur-3xl" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-indigo-400 rounded-full blur-3xl" />
      </div>

      <div className="relative w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-cyan-400 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-2xl shadow-blue-500/30">
            <Warehouse className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-white mb-1">InventarioPro</h1>
          <p className="text-blue-300/70 text-sm">Sistema de Gestión de Inventarios</p>
        </div>

        {/* Login Card */}
        <div className="bg-white/10 backdrop-blur-xl rounded-3xl border border-white/20 p-8 shadow-2xl">
          <div className="mb-6">
            <h2 className="text-xl font-bold text-white mb-1">Iniciar Sesión</h2>
            <p className="text-sm text-blue-200/60">Ingresa tus credenciales para acceder</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-5">
            {/* Email */}
            <div>
              <label className="text-xs font-semibold text-blue-200/80 mb-1.5 block">Correo Electrónico</label>
              <input
                type="email"
                value={email}
                onChange={e => { setEmail(e.target.value); setError(''); }}
                placeholder="admin@inventariopro.com"
                className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-white/30 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400 focus:border-transparent transition-all"
                autoComplete="email"
              />
            </div>

            {/* Password */}
            <div>
              <label className="text-xs font-semibold text-blue-200/80 mb-1.5 block">Contraseña</label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={e => { setPassword(e.target.value); setError(''); }}
                  placeholder="••••••••"
                  className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-xl text-white placeholder-white/30 text-sm focus:outline-none focus:ring-2 focus:ring-blue-400 focus:border-transparent transition-all pr-12"
                  autoComplete="current-password"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 p-1 text-white/40 hover:text-white/70 transition-colors cursor-pointer"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Error */}
            {error && (
              <div className="flex items-center gap-2 bg-red-500/20 border border-red-400/30 rounded-xl px-4 py-3">
                <AlertCircle className="w-4 h-4 text-red-400 flex-shrink-0" />
                <p className="text-sm text-red-300">{error}</p>
              </div>
            )}

            {/* Submit */}
            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 bg-gradient-to-r from-blue-500 to-cyan-500 text-white font-semibold rounded-xl hover:from-blue-600 hover:to-cyan-600 transition-all shadow-lg shadow-blue-500/30 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <>
                  <LogIn className="w-4 h-4" />
                  Iniciar Sesión
                </>
              )}
            </button>
          </form>
        </div>

        {/* Credentials Info */}
        <div className="mt-6 bg-white/5 backdrop-blur-xl rounded-2xl border border-white/10 p-5">
          <div className="flex items-center gap-2 mb-3">
            <Shield className="w-4 h-4 text-cyan-400" />
            <h3 className="text-sm font-semibold text-cyan-300">Credenciales de Acceso</h3>
          </div>
          <div className="space-y-2">
            <div className="flex items-center justify-between bg-white/5 rounded-lg px-3 py-2">
              <div>
                <div className="text-xs text-white/80 font-medium">Administrador</div>
                <div className="text-[10px] text-white/40">admin@inventariopro.com</div>
              </div>
              <div className="text-xs text-cyan-300 font-mono">admin123</div>
            </div>
            <div className="flex items-center justify-between bg-white/5 rounded-lg px-3 py-2">
              <div>
                <div className="text-xs text-white/80 font-medium">Supervisor</div>
                <div className="text-[10px] text-white/40">maria.gonzalez@empresa.com</div>
              </div>
              <div className="text-xs text-cyan-300 font-mono">maria123</div>
            </div>
            <div className="flex items-center justify-between bg-white/5 rounded-lg px-3 py-2">
              <div>
                <div className="text-xs text-white/80 font-medium">Almacén</div>
                <div className="text-[10px] text-white/40">carlos.mendez@empresa.com</div>
              </div>
              <div className="text-xs text-cyan-300 font-mono">carlos123</div>
            </div>
          </div>
        </div>

        <p className="text-center text-xs text-white/20 mt-6">© 2025 InventarioPro v1.0</p>
      </div>
    </div>
  );
}
