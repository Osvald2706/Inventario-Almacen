import { LayoutDashboard, Package, ArrowRightLeft, FolderKanban, Users, FileBarChart, ClipboardList, ChevronLeft, ChevronRight, Warehouse, LogOut } from 'lucide-react';
import { useData } from '../context/DataContext';
import type { Page } from '../types';

interface SidebarProps {
  currentPage: Page;
  onNavigate: (page: Page) => void;
  collapsed: boolean;
  onToggle: () => void;
}

const navItems: { page: Page; label: string; icon: React.ReactNode }[] = [
  { page: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard className="w-5 h-5" /> },
  { page: 'articles', label: 'Artículos', icon: <Package className="w-5 h-5" /> },
  { page: 'movements', label: 'Movimientos', icon: <ArrowRightLeft className="w-5 h-5" /> },
  { page: 'projects', label: 'Proyectos', icon: <FolderKanban className="w-5 h-5" /> },
  { page: 'users', label: 'Usuarios', icon: <Users className="w-5 h-5" /> },
  { page: 'reports', label: 'Reportes', icon: <FileBarChart className="w-5 h-5" /> },
  { page: 'logs', label: 'Bitácora', icon: <ClipboardList className="w-5 h-5" /> },
];

export function Sidebar({ currentPage, onNavigate, collapsed, onToggle }: SidebarProps) {
  const { logout } = useData();

  return (
    <aside className={`fixed top-0 left-0 h-full z-40 bg-slate-950 text-white flex flex-col transition-all duration-300 ${collapsed ? 'w-[72px]' : 'w-64'}`}>
      <div className={`flex items-center gap-3 px-4 h-16 border-b border-slate-800 flex-shrink-0 ${collapsed ? 'justify-center' : ''}`}>
        <div className="w-9 h-9 bg-gradient-to-br from-blue-500 to-cyan-400 rounded-xl flex items-center justify-center flex-shrink-0">
          <Warehouse className="w-5 h-5 text-white" />
        </div>
        {!collapsed && (
          <div className="overflow-hidden">
            <h1 className="text-base font-bold text-white leading-tight">InventarioPro</h1>
            <p className="text-[10px] text-slate-400 font-medium">Control de Almacén</p>
          </div>
        )}
      </div>

      <nav className="flex-1 py-4 px-2 space-y-1 overflow-y-auto">
        {!collapsed && <p className="text-[10px] font-semibold text-slate-500 uppercase tracking-widest px-3 mb-2">Menú principal</p>}
        {navItems.map(item => (
          <button key={item.page} onClick={() => onNavigate(item.page)}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all cursor-pointer group
              ${currentPage === item.page ? 'bg-blue-600/20 text-blue-400 shadow-lg shadow-blue-500/10' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}
              ${collapsed ? 'justify-center' : ''}`}
            title={collapsed ? item.label : undefined}
          >
            <span className={`flex-shrink-0 transition-colors ${currentPage === item.page ? 'text-blue-400' : 'text-slate-500 group-hover:text-white'}`}>
              {item.icon}
            </span>
            {!collapsed && <span>{item.label}</span>}
            {!collapsed && currentPage === item.page && <div className="ml-auto w-1.5 h-1.5 rounded-full bg-blue-400" />}
          </button>
        ))}
      </nav>

      <div className="px-2 pb-2 border-t border-slate-800 pt-2 space-y-1">
        <button onClick={onToggle}
          className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-slate-400 hover:bg-slate-800 hover:text-white transition-all cursor-pointer ${collapsed ? 'justify-center' : ''}`}
        >
          {collapsed ? <ChevronRight className="w-5 h-5" /> : <ChevronLeft className="w-5 h-5" />}
          {!collapsed && <span>Colapsar</span>}
        </button>
        <button onClick={logout}
          className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-slate-400 hover:bg-red-500/10 hover:text-red-400 transition-all cursor-pointer ${collapsed ? 'justify-center' : ''}`}
        >
          <LogOut className="w-5 h-5" />
          {!collapsed && <span>Cerrar Sesión</span>}
        </button>
      </div>
    </aside>
  );
}
