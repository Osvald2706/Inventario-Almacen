import { FileBarChart, Download, Package, FolderKanban, Layers, Users, FileText, BarChart3 } from 'lucide-react';
import { useData } from '../context/DataContext';

function downloadCSV(filename: string, headers: string[], rows: string[][]) {
  const csv = [headers.join(','), ...rows.map(r => r.map(c => `"${c}"`).join(','))].join('\n');
  const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = filename; a.click();
  URL.revokeObjectURL(url);
}

export function ReportsPage() {
  const { articles, movements, projects, users } = useData();

  const exportInventory = () => {
    const headers = ['Código', 'Nombre', 'Categoría', 'Unidad', 'Cantidad', 'Stock Mínimo', 'Ubicación', 'Estado', 'Observaciones'];
    const rows = articles.map(a => [a.code, a.name, a.category, a.unit, String(a.quantity), String(a.minStock), a.location, a.status, a.observations]);
    downloadCSV('inventario_general.csv', headers, rows);
  };

  const exportByProject = () => {
    const headers = ['Proyecto', 'Código Proyecto', 'Artículo', 'Código Artículo', 'Cantidad', 'Módulo', 'Usuario', 'Fecha', 'Observaciones'];
    const rows = movements.filter(m => m.projectName).map(m => [m.projectName || '', m.projectId || '', m.articleName, m.articleCode, String(m.quantity), m.moduleName || '', m.userName, new Date(m.date).toLocaleDateString('es-MX'), m.observations]);
    downloadCSV('reporte_por_proyecto.csv', headers, rows);
  };

  const exportByModule = () => {
    const headers = ['Proyecto', 'Módulo', 'Artículo', 'Cantidad', 'Usuario', 'Fecha'];
    const rows = movements.filter(m => m.moduleName).map(m => [m.projectName || '', m.moduleName || '', m.articleName, String(m.quantity), m.userName, new Date(m.date).toLocaleDateString('es-MX')]);
    downloadCSV('reporte_por_modulo.csv', headers, rows);
  };

  const exportByUser = () => {
    const headers = ['Usuario', 'Tipo', 'Artículo', 'Cantidad', 'Proyecto', 'Fecha', 'Observaciones'];
    const rows = movements.map(m => [m.userName, m.type, m.articleName, String(m.quantity), m.projectName || '—', new Date(m.date).toLocaleDateString('es-MX'), m.observations]);
    downloadCSV('reporte_por_usuario.csv', headers, rows);
  };

  const exportArticleHistory = () => {
    const headers = ['Artículo', 'Código', 'Tipo', 'Cantidad', 'Razón', 'Usuario', 'Proyecto', 'Módulo', 'Fecha', 'Observaciones'];
    const rows = movements.map(m => [m.articleName, m.articleCode, m.type, String(m.quantity), m.reason, m.userName, m.projectName || '', m.moduleName || '', new Date(m.date).toLocaleDateString('es-MX'), m.observations]);
    downloadCSV('historial_articulos.csv', headers, rows);
  };

  const exportAlerts = () => {
    const headers = ['Código', 'Artículo', 'Cantidad Actual', 'Stock Mínimo', 'Ubicación', 'Estado'];
    const rows = articles.filter(a => a.quantity <= a.minStock).map(a => [a.code, a.name, String(a.quantity), String(a.minStock), a.location, a.quantity === 0 ? 'SIN STOCK' : 'BAJO']);
    downloadCSV('alertas_stock.csv', headers, rows);
  };

  const reports = [
    { id: 'inv-general', title: 'Inventario General', description: 'Listado completo de todos los artículos con cantidades, ubicaciones y estados actuales.', icon: <Package className="w-6 h-6" />, color: 'from-blue-500 to-indigo-600', data: `${articles.length} artículos | ${articles.reduce((s, a) => s + a.quantity, 0)} unidades totales`, onExport: exportInventory },
    { id: 'by-project', title: 'Reporte por Proyecto', description: 'Materiales y herramientas asignados a cada proyecto con desglose por módulo.', icon: <FolderKanban className="w-6 h-6" />, color: 'from-emerald-500 to-teal-600', data: `${projects.length} proyectos | ${movements.filter(m => m.projectId).length} salidas registradas`, onExport: exportByProject },
    { id: 'by-module', title: 'Reporte por Módulo', description: 'Desglose detallado de materiales consumidos por cada módulo de cada proyecto.', icon: <Layers className="w-6 h-6" />, color: 'from-purple-500 to-violet-600', data: `${projects.reduce((s, p) => s + p.modules.length, 0)} módulos registrados`, onExport: exportByModule },
    { id: 'by-user', title: 'Reporte por Usuario', description: 'Movimientos realizados por cada usuario del sistema con fechas y cantidades.', icon: <Users className="w-6 h-6" />, color: 'from-amber-500 to-orange-600', data: `${users.length} usuarios | ${movements.length} movimientos totales`, onExport: exportByUser },
    { id: 'article-history', title: 'Historial de Artículos', description: 'Trazabilidad completa de artículos: todas las entradas, salidas y movimientos.', icon: <FileText className="w-6 h-6" />, color: 'from-rose-500 to-pink-600', data: `${movements.length} movimientos registrados`, onExport: exportArticleHistory },
    { id: 'stock-alerts', title: 'Alertas de Stock', description: 'Artículos con stock bajo o agotado que requieren atención inmediata.', icon: <BarChart3 className="w-6 h-6" />, color: 'from-red-500 to-rose-600', data: `${articles.filter(a => a.quantity <= a.minStock).length} artículos en alerta`, onExport: exportAlerts },
  ];

  const categoryStats: Record<string, { count: number; total: number }> = {};
  articles.forEach(a => {
    if (!categoryStats[a.category]) categoryStats[a.category] = { count: 0, total: 0 };
    categoryStats[a.category].count++;
    categoryStats[a.category].total += a.quantity;
  });

  return (
    <div>
      <div className="mb-6">
        <h2 className="text-2xl sm:text-3xl font-bold text-slate-900">Reportes</h2>
        <p className="text-slate-500 mt-1">Genera y descarga informes del almacén en formato CSV</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
        {reports.map(report => (
          <div key={report.id} className="bg-white rounded-2xl border border-slate-200 p-6 hover:shadow-lg hover:border-slate-300 transition-all group">
            <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${report.color} flex items-center justify-center text-white mb-4 shadow-lg`}>
              {report.icon}
            </div>
            <h3 className="font-bold text-slate-900 mb-1">{report.title}</h3>
            <p className="text-sm text-slate-500 mb-3 leading-relaxed">{report.description}</p>
            <p className="text-xs text-slate-400 mb-4">{report.data}</p>
            <button onClick={report.onExport} className="flex items-center gap-1.5 px-4 py-2.5 bg-blue-600 text-white text-xs font-semibold rounded-xl hover:bg-blue-700 transition-colors cursor-pointer shadow-lg shadow-blue-200 w-full justify-center">
              <Download className="w-3.5 h-3.5" /> Descargar CSV
            </button>
          </div>
        ))}
      </div>

      {/* Preview */}
      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <FileBarChart className="w-5 h-5 text-slate-400" />
            <h3 className="font-semibold text-slate-900">Vista Previa: Inventario por Categoría</h3>
          </div>
          <button onClick={exportInventory} className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-50 text-blue-600 text-xs font-semibold rounded-lg hover:bg-blue-100 cursor-pointer">
            <Download className="w-3 h-3" /> Exportar
          </button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-slate-50">
                <th className="px-6 py-3 text-left text-xs font-semibold text-slate-500 uppercase">Categoría</th>
                <th className="px-6 py-3 text-left text-xs font-semibold text-slate-500 uppercase">Artículos</th>
                <th className="px-6 py-3 text-left text-xs font-semibold text-slate-500 uppercase">Unidades Totales</th>
                <th className="px-6 py-3 text-left text-xs font-semibold text-slate-500 uppercase">Distribución</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {Object.entries(categoryStats).map(([cat, stats]) => {
                const maxTotal = Math.max(...Object.values(categoryStats).map(s => s.total));
                const totalUnits = articles.reduce((s, a) => s + a.quantity, 0);
                const colors: Record<string, string> = { herramienta: 'bg-blue-500', material: 'bg-emerald-500', refacción: 'bg-purple-500', consumible: 'bg-amber-500', equipo: 'bg-rose-500', EPP: 'bg-cyan-500', eléctrico: 'bg-indigo-500', otro: 'bg-slate-500' };
                return (
                  <tr key={cat} className="hover:bg-slate-50">
                    <td className="px-6 py-3 font-medium text-slate-800 capitalize">{cat}</td>
                    <td className="px-6 py-3 text-slate-600">{stats.count}</td>
                    <td className="px-6 py-3 font-bold text-slate-900">{stats.total.toLocaleString()}</td>
                    <td className="px-6 py-3">
                      <div className="flex items-center gap-2">
                        <div className="flex-1 h-2 bg-slate-100 rounded-full overflow-hidden max-w-[200px]">
                          <div className={`h-full ${colors[cat] || 'bg-slate-400'} rounded-full`} style={{ width: `${maxTotal > 0 ? (stats.total / maxTotal) * 100 : 0}%` }} />
                        </div>
                        <span className="text-xs text-slate-500">{totalUnits > 0 ? Math.round((stats.total / totalUnits) * 100) : 0}%</span>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
