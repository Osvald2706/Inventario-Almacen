import { ClipboardList, User, Clock, Shield } from 'lucide-react';
import { useData } from '../context/DataContext';

const actionColors: Record<string, string> = {
  'Salida registrada': 'bg-red-100 text-red-700 border-red-200',
  'Entrada registrada': 'bg-emerald-100 text-emerald-700 border-emerald-200',
  'Artículo creado': 'bg-blue-100 text-blue-700 border-blue-200',
  'Artículo eliminado': 'bg-red-100 text-red-700 border-red-200',
  'Proyecto creado': 'bg-purple-100 text-purple-700 border-purple-200',
  'Proyecto eliminado': 'bg-red-100 text-red-700 border-red-200',
  'Usuario creado': 'bg-cyan-100 text-cyan-700 border-cyan-200',
  'Usuario eliminado': 'bg-red-100 text-red-700 border-red-200',
  'Usuario desactivado': 'bg-amber-100 text-amber-700 border-amber-200',
  'Movimiento eliminado': 'bg-orange-100 text-orange-700 border-orange-200',
};

export function LogsPage() {
  const { logs } = useData();

  const formatDateTime = (d: string) => new Date(d).toLocaleDateString('es-MX', {
    day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit'
  });

  return (
    <div>
      <div className="mb-6">
        <h2 className="text-2xl sm:text-3xl font-bold text-slate-900">Bitácora de Actividad</h2>
        <p className="text-slate-500 mt-1">Registro de todas las acciones del sistema (auditoría)</p>
      </div>

      <div className="bg-gradient-to-r from-amber-50 to-orange-50 rounded-2xl p-5 border border-amber-200 mb-6 flex items-start gap-3">
        <Shield className="w-5 h-5 text-amber-500 flex-shrink-0 mt-0.5" />
        <div>
          <h4 className="font-semibold text-amber-900 text-sm">Registro de Auditoría</h4>
          <p className="text-xs text-amber-700 mt-1">Todos los movimientos, creaciones y eliminaciones quedan registrados automáticamente con usuario, fecha y hora.</p>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-100 flex items-center gap-2">
          <ClipboardList className="w-5 h-5 text-slate-400" />
          <h3 className="font-semibold text-slate-900">Actividad Reciente</h3>
          <span className="ml-auto text-xs text-slate-500">{logs.length} registros</span>
        </div>

        <div className="divide-y divide-slate-50">
          {logs.map((log, i) => (
            <div key={log.id} className="px-6 py-4 hover:bg-slate-50 transition-colors flex items-start gap-4">
              <div className="flex flex-col items-center flex-shrink-0 mt-1">
                <div className={`w-3 h-3 rounded-full ${i === 0 ? 'bg-blue-500 ring-4 ring-blue-100' : 'bg-slate-300'}`} />
                {i < logs.length - 1 && <div className="w-0.5 h-full bg-slate-200 mt-1 min-h-[20px]" />}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex flex-wrap items-center gap-2 mb-1">
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${actionColors[log.action] || 'bg-slate-100 text-slate-600 border-slate-200'}`}>
                    {log.action.toUpperCase()}
                  </span>
                </div>
                <p className="text-sm text-slate-800 leading-relaxed">{log.detail}</p>
                <div className="flex items-center gap-3 mt-1.5 text-xs text-slate-400">
                  <span className="flex items-center gap-1"><User className="w-3 h-3" /> {log.userName}</span>
                  <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> {formatDateTime(log.timestamp)}</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {logs.length === 0 && (
          <div className="py-16 text-center">
            <ClipboardList className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <p className="text-slate-500 font-medium">Sin actividad registrada</p>
          </div>
        )}
      </div>
    </div>
  );
}
