import { useState } from 'react';
import { FolderKanban, Calendar, Users, ChevronDown, ChevronUp, Layers, ArrowUpFromLine, Plus, X, Trash2 } from 'lucide-react';
import { useData } from '../context/DataContext';
import type { ProjectStatus } from '../types';

const statusConfig: Record<ProjectStatus, { label: string; color: string }> = {
  activo: { label: 'ACTIVO', color: 'bg-emerald-100 text-emerald-700' },
  cerrado: { label: 'CERRADO', color: 'bg-slate-200 text-slate-600' },
  pausado: { label: 'PAUSADO', color: 'bg-amber-100 text-amber-700' },
};

export function ProjectsPage() {
  const { projects, movements, addProject, deleteProject } = useData();
  const [expandedId, setExpandedId] = useState<string | null>(projects[0]?.id || null);
  const [showForm, setShowForm] = useState(false);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const [formData, setFormData] = useState({ code: '', name: '', client: '', startDate: '', endDate: '', status: 'activo' as ProjectStatus, modulesText: '' });

  const getProjectMovements = (projectId: string) => movements.filter(m => m.projectId === projectId);

  const handleSave = () => {
    if (!formData.code || !formData.name) return;
    const modules = formData.modulesText.split(',').filter(m => m.trim()).map((m, i) => ({
      id: `mod-new-${Date.now()}-${i}`, name: m.trim(), projectId: ''
    }));
    addProject({ code: formData.code, name: formData.name, client: formData.client, startDate: formData.startDate, endDate: formData.endDate, status: formData.status, modules });
    setFormData({ code: '', name: '', client: '', startDate: '', endDate: '', status: 'activo', modulesText: '' });
    setShowForm(false);
  };

  const handleDelete = (id: string) => { deleteProject(id); setDeleteConfirm(null); };

  return (
    <div>
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
        <div>
          <h2 className="text-2xl sm:text-3xl font-bold text-slate-900">Proyectos</h2>
          <p className="text-slate-500 mt-1">Gestión de proyectos y módulos — Trazabilidad de materiales</p>
        </div>
        <button onClick={() => setShowForm(!showForm)} className="flex items-center gap-2 px-5 py-2.5 bg-blue-600 text-white text-sm font-semibold rounded-xl hover:bg-blue-700 transition-colors shadow-lg shadow-blue-200 cursor-pointer">
          <Plus className="w-4 h-4" /> Nuevo Proyecto
        </button>
      </div>

      {showForm && (
        <div className="mb-6 bg-white rounded-2xl border border-slate-200 p-6 shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold text-lg text-slate-900">Crear Nuevo Proyecto</h3>
            <button onClick={() => setShowForm(false)} className="p-1 hover:bg-slate-100 rounded-lg cursor-pointer"><X className="w-5 h-5 text-slate-400" /></button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <div><label className="text-xs font-semibold text-slate-500 mb-1 block">Código *</label><input type="text" value={formData.code} onChange={e => setFormData({...formData, code: e.target.value})} placeholder="PROY-2025-004" className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" /></div>
            <div><label className="text-xs font-semibold text-slate-500 mb-1 block">Nombre *</label><input type="text" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} placeholder="Nombre del proyecto" className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" /></div>
            <div><label className="text-xs font-semibold text-slate-500 mb-1 block">Cliente</label><input type="text" value={formData.client} onChange={e => setFormData({...formData, client: e.target.value})} placeholder="Nombre del cliente" className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" /></div>
            <div><label className="text-xs font-semibold text-slate-500 mb-1 block">Fecha de Inicio</label><input type="date" value={formData.startDate} onChange={e => setFormData({...formData, startDate: e.target.value})} className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" /></div>
            <div><label className="text-xs font-semibold text-slate-500 mb-1 block">Fecha de Cierre</label><input type="date" value={formData.endDate} onChange={e => setFormData({...formData, endDate: e.target.value})} className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" /></div>
            <div><label className="text-xs font-semibold text-slate-500 mb-1 block">Estado</label>
              <select value={formData.status} onChange={e => setFormData({...formData, status: e.target.value as ProjectStatus})} className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-sm bg-white focus:outline-none focus:ring-2 focus:ring-blue-500">
                <option value="activo">Activo</option><option value="pausado">Pausado</option><option value="cerrado">Cerrado</option>
              </select>
            </div>
            <div className="sm:col-span-2 lg:col-span-3">
              <label className="text-xs font-semibold text-slate-500 mb-1 block">Módulos (separados por coma)</label>
              <input type="text" value={formData.modulesText} onChange={e => setFormData({...formData, modulesText: e.target.value})} placeholder="Cimentación, Estructura, Acabados" className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
            </div>
          </div>
          <div className="flex justify-end gap-3 mt-6">
            <button onClick={() => setShowForm(false)} className="px-5 py-2.5 border border-slate-200 rounded-xl text-sm font-medium text-slate-600 hover:bg-slate-50 cursor-pointer">Cancelar</button>
            <button onClick={handleSave} className="px-5 py-2.5 bg-blue-600 text-white rounded-xl text-sm font-semibold hover:bg-blue-700 cursor-pointer shadow-lg shadow-blue-200">Crear Proyecto</button>
          </div>
        </div>
      )}

      {/* Delete Confirm */}
      {deleteConfirm && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" onClick={() => setDeleteConfirm(null)}>
          <div className="bg-white rounded-2xl max-w-sm w-full p-6 shadow-2xl" onClick={e => e.stopPropagation()}>
            <div className="w-14 h-14 bg-red-100 rounded-2xl flex items-center justify-center mx-auto mb-4"><Trash2 className="w-7 h-7 text-red-600" /></div>
            <h3 className="font-bold text-lg text-slate-900 text-center mb-2">¿Eliminar proyecto?</h3>
            <p className="text-sm text-slate-500 text-center mb-6">Se eliminará el proyecto y todos sus módulos permanentemente.</p>
            <div className="flex gap-3">
              <button onClick={() => setDeleteConfirm(null)} className="flex-1 px-4 py-2.5 border border-slate-200 rounded-xl text-sm font-medium text-slate-600 hover:bg-slate-50 cursor-pointer">Cancelar</button>
              <button onClick={() => handleDelete(deleteConfirm)} className="flex-1 px-4 py-2.5 bg-red-600 text-white rounded-xl text-sm font-semibold hover:bg-red-700 cursor-pointer">Eliminar</button>
            </div>
          </div>
        </div>
      )}

      {/* Projects List */}
      <div className="space-y-4">
        {projects.map(project => {
          const mvs = getProjectMovements(project.id);
          const totalItems = mvs.reduce((sum, m) => sum + m.quantity, 0);
          const isExpanded = expandedId === project.id;

          return (
            <div key={project.id} className={`bg-white rounded-2xl border-2 overflow-hidden transition-all ${isExpanded ? 'border-blue-200 shadow-xl shadow-blue-50' : 'border-slate-200 hover:border-slate-300 shadow-sm'}`}>
              <div className="p-5 cursor-pointer" onClick={() => setExpandedId(isExpanded ? null : project.id)}>
                <div className="flex items-center gap-4">
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 ${project.status === 'activo' ? 'bg-gradient-to-br from-blue-500 to-indigo-600' : project.status === 'pausado' ? 'bg-gradient-to-br from-amber-400 to-orange-500' : 'bg-gradient-to-br from-slate-400 to-slate-500'}`}>
                    <FolderKanban className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-0.5">
                      <h3 className="font-bold text-slate-900 truncate">{project.name}</h3>
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${statusConfig[project.status].color}`}>{statusConfig[project.status].label}</span>
                    </div>
                    <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-500">
                      <span className="font-mono">{project.code}</span>
                      {project.client && <span className="flex items-center gap-1"><Users className="w-3 h-3" /> {project.client}</span>}
                      <span className="flex items-center gap-1"><Calendar className="w-3 h-3" /> {project.startDate ? new Date(project.startDate).toLocaleDateString('es-MX') : '—'} — {project.endDate ? new Date(project.endDate).toLocaleDateString('es-MX') : '—'}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 flex-shrink-0">
                    <div className="text-right hidden sm:block">
                      <div className="text-lg font-bold text-slate-900">{totalItems}</div>
                      <div className="text-[10px] text-slate-400">Unidades salidas</div>
                    </div>
                    <button onClick={e => { e.stopPropagation(); setDeleteConfirm(project.id); }} className="p-2 hover:bg-red-50 rounded-lg cursor-pointer" title="Eliminar proyecto">
                      <Trash2 className="w-4 h-4 text-red-400" />
                    </button>
                    <div className={`p-2 rounded-lg ${isExpanded ? 'bg-blue-100' : 'bg-slate-100'}`}>
                      {isExpanded ? <ChevronUp className="w-5 h-5 text-blue-600" /> : <ChevronDown className="w-5 h-5 text-slate-400" />}
                    </div>
                  </div>
                </div>
              </div>

              {isExpanded && (
                <div className="px-5 pb-5 border-t border-slate-100 pt-4">
                  <div className="grid grid-cols-3 gap-3 mb-5">
                    <div className="bg-blue-50 rounded-xl p-3 text-center border border-blue-100">
                      <div className="text-xl font-bold text-blue-700">{project.modules.length}</div>
                      <div className="text-[10px] text-blue-500 font-medium">Módulos</div>
                    </div>
                    <div className="bg-purple-50 rounded-xl p-3 text-center border border-purple-100">
                      <div className="text-xl font-bold text-purple-700">{mvs.length}</div>
                      <div className="text-[10px] text-purple-500 font-medium">Movimientos</div>
                    </div>
                    <div className="bg-emerald-50 rounded-xl p-3 text-center border border-emerald-100">
                      <div className="text-xl font-bold text-emerald-700">{totalItems}</div>
                      <div className="text-[10px] text-emerald-500 font-medium">Unidades</div>
                    </div>
                  </div>

                  <h4 className="text-sm font-semibold text-slate-700 mb-3 flex items-center gap-2">
                    <Layers className="w-4 h-4 text-slate-400" /> Módulos del Proyecto
                  </h4>
                  <div className="space-y-2">
                    {project.modules.map(mod => {
                      const modMovements = mvs.filter(m => m.moduleId === mod.id);
                      const modTotal = modMovements.reduce((s, m) => s + m.quantity, 0);
                      return (
                        <div key={mod.id} className="bg-slate-50 rounded-xl p-4 border border-slate-100">
                          <div className="flex items-center justify-between mb-2">
                            <span className="font-medium text-slate-800 text-sm">{mod.name}</span>
                            <span className="text-xs text-slate-500">{modTotal} unidades | {modMovements.length} salidas</span>
                          </div>
                          {modMovements.length > 0 ? (
                            <div className="space-y-1">
                              {modMovements.map(mm => (
                                <div key={mm.id} className="flex items-center justify-between text-xs bg-white rounded-lg px-3 py-2 border border-slate-100">
                                  <div className="flex items-center gap-2">
                                    <ArrowUpFromLine className="w-3 h-3 text-red-500" />
                                    <span className="text-slate-700">{mm.articleName}</span>
                                    <span className="text-red-600 font-bold">-{mm.quantity}</span>
                                  </div>
                                  <div className="flex items-center gap-2 text-slate-400">
                                    <span>{mm.userName}</span>
                                    <span>{new Date(mm.date).toLocaleDateString('es-MX')}</span>
                                  </div>
                                </div>
                              ))}
                            </div>
                          ) : (
                            <p className="text-xs text-slate-400 italic">Sin movimientos registrados</p>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          );
        })}
        {projects.length === 0 && (
          <div className="py-16 text-center bg-white rounded-2xl border border-slate-200">
            <FolderKanban className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <p className="text-slate-500 font-medium">No hay proyectos registrados</p>
          </div>
        )}
      </div>
    </div>
  );
}
