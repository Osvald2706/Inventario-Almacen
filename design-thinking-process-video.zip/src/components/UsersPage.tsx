import { Users, Shield, Eye, Package, UserCheck, UserX, Plus, X, Trash2 } from 'lucide-react';
import { useData } from '../context/DataContext';
import { useState } from 'react';
import type { UserRole } from '../types';

const roleConfig: Record<UserRole, { label: string; color: string; icon: React.ReactNode; perms: string[] }> = {
  administrador: { label: 'Administrador', color: 'bg-red-100 text-red-700', icon: <Shield className="w-4 h-4" />, perms: ['Ver', 'Registrar', 'Editar', 'Eliminar', 'Autorizar', 'Exportar', 'Config. Sistema'] },
  supervisor: { label: 'Supervisor', color: 'bg-purple-100 text-purple-700', icon: <Eye className="w-4 h-4" />, perms: ['Ver', 'Registrar', 'Editar', 'Autorizar', 'Exportar'] },
  almacén: { label: 'Almacén', color: 'bg-blue-100 text-blue-700', icon: <Package className="w-4 h-4" />, perms: ['Ver', 'Registrar'] },
  consulta: { label: 'Consulta', color: 'bg-slate-200 text-slate-600', icon: <Eye className="w-4 h-4" />, perms: ['Ver'] },
};

const avatarColors = ['from-blue-500 to-indigo-600', 'from-emerald-500 to-teal-600', 'from-amber-500 to-orange-600', 'from-purple-500 to-violet-600', 'from-rose-500 to-pink-600', 'from-cyan-500 to-sky-600'];

export function UsersPage() {
  const { users, addUser, deleteUser, currentUser } = useData();
  const [showForm, setShowForm] = useState(false);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const [formData, setFormData] = useState({ name: '', email: '', password: '', role: 'almacén' as UserRole });
  const [formError, setFormError] = useState('');

  const handleSave = () => {
    setFormError('');
    if (!formData.name.trim() || !formData.email.trim() || !formData.password.trim()) {
      setFormError('Todos los campos son obligatorios');
      return;
    }
    if (formData.password.length < 6) {
      setFormError('La contraseña debe tener al menos 6 caracteres');
      return;
    }
    if (users.some(u => u.email.toLowerCase() === formData.email.toLowerCase())) {
      setFormError('Ya existe un usuario con ese correo electrónico');
      return;
    }
    const nameParts = formData.name.trim().split(' ');
    const avatar = nameParts.length >= 2 ? `${nameParts[0][0]}${nameParts[1][0]}`.toUpperCase() : formData.name.slice(0, 2).toUpperCase();
    addUser({
      name: formData.name, email: formData.email, password: formData.password,
      role: formData.role, avatar, active: true, lastLogin: new Date().toISOString()
    });
    setFormData({ name: '', email: '', password: '', role: 'almacén' });
    setShowForm(false);
  };

  const handleDelete = (id: string) => {
    deleteUser(id);
    setDeleteConfirm(null);
  };

  return (
    <div>
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
        <div>
          <h2 className="text-2xl sm:text-3xl font-bold text-slate-900">Usuarios y Roles</h2>
          <p className="text-slate-500 mt-1">Control de accesos y permisos del sistema</p>
        </div>
        <button onClick={() => { setShowForm(!showForm); setFormError(''); }} className="flex items-center gap-2 px-5 py-2.5 bg-blue-600 text-white text-sm font-semibold rounded-xl hover:bg-blue-700 transition-colors shadow-lg shadow-blue-200 cursor-pointer">
          <Plus className="w-4 h-4" /> Nuevo Usuario
        </button>
      </div>

      {showForm && (
        <div className="mb-6 bg-white rounded-2xl border border-slate-200 p-6 shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold text-lg text-slate-900">Registrar Nuevo Usuario</h3>
            <button onClick={() => setShowForm(false)} className="p-1 hover:bg-slate-100 rounded-lg cursor-pointer"><X className="w-5 h-5 text-slate-400" /></button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div><label className="text-xs font-semibold text-slate-500 mb-1 block">Nombre Completo *</label><input type="text" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} placeholder="Juan Pérez" className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" /></div>
            <div><label className="text-xs font-semibold text-slate-500 mb-1 block">Correo Electrónico *</label><input type="email" value={formData.email} onChange={e => setFormData({...formData, email: e.target.value})} placeholder="usuario@empresa.com" className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" /></div>
            <div><label className="text-xs font-semibold text-slate-500 mb-1 block">Contraseña *</label><input type="password" value={formData.password} onChange={e => setFormData({...formData, password: e.target.value})} placeholder="Mínimo 6 caracteres" className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" /></div>
            <div><label className="text-xs font-semibold text-slate-500 mb-1 block">Rol *</label>
              <select value={formData.role} onChange={e => setFormData({...formData, role: e.target.value as UserRole})} className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-sm bg-white focus:outline-none focus:ring-2 focus:ring-blue-500">
                {Object.entries(roleConfig).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
              </select>
            </div>
          </div>
          {formError && (
            <div className="mt-3 px-4 py-2.5 bg-red-50 border border-red-200 rounded-xl text-sm text-red-600">{formError}</div>
          )}
          <div className="flex justify-end gap-3 mt-6">
            <button onClick={() => setShowForm(false)} className="px-5 py-2.5 border border-slate-200 rounded-xl text-sm font-medium text-slate-600 hover:bg-slate-50 cursor-pointer">Cancelar</button>
            <button onClick={handleSave} className="px-5 py-2.5 bg-blue-600 text-white rounded-xl text-sm font-semibold hover:bg-blue-700 cursor-pointer shadow-lg shadow-blue-200">Crear Usuario</button>
          </div>
        </div>
      )}

      {/* Delete Confirm */}
      {deleteConfirm && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" onClick={() => setDeleteConfirm(null)}>
          <div className="bg-white rounded-2xl max-w-sm w-full p-6 shadow-2xl" onClick={e => e.stopPropagation()}>
            <div className="w-14 h-14 bg-red-100 rounded-2xl flex items-center justify-center mx-auto mb-4"><Trash2 className="w-7 h-7 text-red-600" /></div>
            <h3 className="font-bold text-lg text-slate-900 text-center mb-2">¿Eliminar usuario?</h3>
            <p className="text-sm text-slate-500 text-center mb-6">
              {deleteConfirm === currentUser?.id
                ? 'No puedes eliminarte a ti mismo.'
                : 'Se eliminará este usuario permanentemente del sistema.'
              }
            </p>
            <div className="flex gap-3">
              <button onClick={() => setDeleteConfirm(null)} className="flex-1 px-4 py-2.5 border border-slate-200 rounded-xl text-sm font-medium text-slate-600 hover:bg-slate-50 cursor-pointer">Cancelar</button>
              {deleteConfirm !== currentUser?.id && (
                <button onClick={() => handleDelete(deleteConfirm)} className="flex-1 px-4 py-2.5 bg-red-600 text-white rounded-xl text-sm font-semibold hover:bg-red-700 cursor-pointer">Eliminar</button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Roles Overview */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {Object.entries(roleConfig).map(([key, config]) => {
          const count = users.filter(u => u.role === key).length;
          return (
            <div key={key} className="bg-white rounded-2xl border border-slate-200 p-5">
              <div className="flex items-center justify-between mb-3">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${config.color}`}>{config.icon}</div>
                <span className="text-2xl font-bold text-slate-900">{count}</span>
              </div>
              <h4 className="font-semibold text-slate-800 text-sm mb-2">{config.label}</h4>
              <div className="flex flex-wrap gap-1">
                {config.perms.map(p => (
                  <span key={p} className="text-[10px] px-2 py-0.5 bg-slate-100 text-slate-500 rounded-full font-medium">{p}</span>
                ))}
              </div>
            </div>
          );
        })}
      </div>

      {/* Users Table */}
      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-100 flex items-center gap-2">
          <Users className="w-5 h-5 text-slate-400" />
          <h3 className="font-semibold text-slate-900">Todos los Usuarios</h3>
          <span className="ml-auto text-xs text-slate-500">{users.length} registros</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-slate-50">
                <th className="px-6 py-3 text-left text-xs font-semibold text-slate-500 uppercase">Usuario</th>
                <th className="px-6 py-3 text-left text-xs font-semibold text-slate-500 uppercase">Email</th>
                <th className="px-6 py-3 text-left text-xs font-semibold text-slate-500 uppercase">Rol</th>
                <th className="px-6 py-3 text-left text-xs font-semibold text-slate-500 uppercase">Estado</th>
                <th className="px-6 py-3 text-left text-xs font-semibold text-slate-500 uppercase">Último Acceso</th>
                <th className="px-6 py-3 text-left text-xs font-semibold text-slate-500 uppercase">Acciones</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {users.map((user, i) => (
                <tr key={user.id} className={`hover:bg-slate-50 transition-colors ${user.id === currentUser?.id ? 'bg-blue-50/30' : ''}`}>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${avatarColors[i % avatarColors.length]} flex items-center justify-center text-white font-bold text-sm`}>{user.avatar}</div>
                      <div>
                        <span className="font-medium text-slate-900">{user.name}</span>
                        {user.id === currentUser?.id && <span className="ml-2 text-[10px] bg-blue-100 text-blue-700 px-1.5 py-0.5 rounded-full font-bold">TÚ</span>}
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-slate-500">{user.email}</td>
                  <td className="px-6 py-4">
                    <span className={`text-xs font-bold px-2.5 py-1 rounded-full ${roleConfig[user.role].color}`}>{roleConfig[user.role].label}</span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-1.5">
                      {user.active ? <UserCheck className="w-4 h-4 text-emerald-500" /> : <UserX className="w-4 h-4 text-slate-400" />}
                      <span className={`text-xs font-medium ${user.active ? 'text-emerald-600' : 'text-slate-400'}`}>{user.active ? 'Activo' : 'Inactivo'}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-xs text-slate-500">{new Date(user.lastLogin).toLocaleDateString('es-MX', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' })}</td>
                  <td className="px-6 py-4">
                    <button onClick={() => setDeleteConfirm(user.id)} className="p-2 hover:bg-red-50 rounded-lg cursor-pointer" title="Eliminar usuario">
                      <Trash2 className="w-4 h-4 text-red-400" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
