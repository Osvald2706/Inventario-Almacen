import { useState } from 'react';
import { ArrowRightLeft, ArrowDownToLine, ArrowUpFromLine, Search, X, FolderKanban, User, FileText, Trash2 } from 'lucide-react';
import { useData } from '../context/DataContext';
import type { Movement } from '../types';

export function MovementsPage() {
  const { movements, articles, projects, addMovement, deleteMovement, currentUser } = useData();
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [showForm, setShowForm] = useState(false);
  const [formType, setFormType] = useState<'entrada' | 'salida'>('entrada');
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);

  // Form state
  const [formData, setFormData] = useState({ articleId: '', quantity: 0, reason: 'compra', projectId: '', moduleId: '', authorizedBy: '', observations: '' });

  const selectedArticle = articles.find(a => a.id === formData.articleId);
  const selectedProject = projects.find(p => p.id === formData.projectId);

  const filtered = movements.filter(m => {
    const matchSearch = m.articleName.toLowerCase().includes(search.toLowerCase()) || m.articleCode.toLowerCase().includes(search.toLowerCase()) || m.userName.toLowerCase().includes(search.toLowerCase());
    const matchType = typeFilter === 'all' || m.type === typeFilter;
    return matchSearch && matchType;
  }).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  const formatDate = (d: string) => new Date(d).toLocaleDateString('es-MX', { day: '2-digit', month: 'short', year: 'numeric' });
  const formatTime = (d: string) => new Date(d).toLocaleTimeString('es-MX', { hour: '2-digit', minute: '2-digit' });

  const handleSave = () => {
    if (!formData.articleId || formData.quantity <= 0) return;
    const art = articles.find(a => a.id === formData.articleId);
    if (!art) return;
    const proj = projects.find(p => p.id === formData.projectId);
    const mod = proj?.modules.find(m => m.id === formData.moduleId);

    const mv: Omit<Movement, 'id'> = {
      articleId: art.id, articleName: art.name, articleCode: art.code,
      type: formType, quantity: formData.quantity, date: new Date().toISOString(),
      reason: formType === 'entrada' ? formData.reason : 'Uso en proyecto',
      userId: currentUser?.id || 'u1', userName: currentUser?.name || 'Sistema',
      projectId: proj?.id, projectName: proj?.name,
      moduleId: mod?.id, moduleName: mod?.name,
      authorizedBy: formData.authorizedBy, observations: formData.observations,
    };
    addMovement(mv);
    setFormData({ articleId: '', quantity: 0, reason: 'compra', projectId: '', moduleId: '', authorizedBy: '', observations: '' });
    setShowForm(false);
  };

  const handleDelete = (id: string) => { deleteMovement(id); setDeleteConfirm(null); };

  return (
    <div>
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
        <div>
          <h2 className="text-2xl sm:text-3xl font-bold text-slate-900">Movimientos</h2>
          <p className="text-slate-500 mt-1">Control de entradas y salidas del almacén</p>
        </div>
        <div className="flex gap-2">
          <button onClick={() => { setShowForm(true); setFormType('entrada'); }} className="flex items-center gap-2 px-4 py-2.5 bg-emerald-600 text-white text-sm font-semibold rounded-xl hover:bg-emerald-700 transition-colors shadow-lg shadow-emerald-200 cursor-pointer">
            <ArrowDownToLine className="w-4 h-4" /> Entrada
          </button>
          <button onClick={() => { setShowForm(true); setFormType('salida'); }} className="flex items-center gap-2 px-4 py-2.5 bg-red-600 text-white text-sm font-semibold rounded-xl hover:bg-red-700 transition-colors shadow-lg shadow-red-200 cursor-pointer">
            <ArrowUpFromLine className="w-4 h-4" /> Salida
          </button>
        </div>
      </div>

      {showForm && (
        <div className="mb-6 bg-white rounded-2xl border border-slate-200 p-6 shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${formType === 'entrada' ? 'bg-emerald-100' : 'bg-red-100'}`}>
                {formType === 'entrada' ? <ArrowDownToLine className="w-5 h-5 text-emerald-600" /> : <ArrowUpFromLine className="w-5 h-5 text-red-600" />}
              </div>
              <h3 className="font-bold text-lg text-slate-900">Registrar {formType === 'entrada' ? 'Entrada' : 'Salida'}</h3>
            </div>
            <button onClick={() => setShowForm(false)} className="p-1 hover:bg-slate-100 rounded-lg cursor-pointer"><X className="w-5 h-5 text-slate-400" /></button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <div>
              <label className="text-xs font-semibold text-slate-500 mb-1 block">Artículo *</label>
              <select value={formData.articleId} onChange={e => setFormData({...formData, articleId: e.target.value})} className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-sm bg-white focus:outline-none focus:ring-2 focus:ring-blue-500">
                <option value="">Seleccionar artículo</option>
                {articles.map(a => <option key={a.id} value={a.id}>{a.code} — {a.name} ({a.quantity} {a.unit})</option>)}
              </select>
              {selectedArticle && <p className="text-xs text-slate-400 mt-1">Stock actual: {selectedArticle.quantity} {selectedArticle.unit}</p>}
            </div>
            <div>
              <label className="text-xs font-semibold text-slate-500 mb-1 block">Cantidad *</label>
              <input type="number" min="1" value={formData.quantity || ''} onChange={e => setFormData({...formData, quantity: Number(e.target.value)})} placeholder="0" className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
            </div>
            {formType === 'entrada' ? (
              <div>
                <label className="text-xs font-semibold text-slate-500 mb-1 block">Motivo *</label>
                <select value={formData.reason} onChange={e => setFormData({...formData, reason: e.target.value})} className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-sm bg-white focus:outline-none focus:ring-2 focus:ring-blue-500">
                  <option value="compra">Compra</option><option value="devolución">Devolución</option><option value="ajuste">Ajuste</option><option value="transferencia">Transferencia</option><option value="donación">Donación</option>
                </select>
              </div>
            ) : (
              <>
                <div>
                  <label className="text-xs font-semibold text-slate-500 mb-1 block">Proyecto *</label>
                  <select value={formData.projectId} onChange={e => setFormData({...formData, projectId: e.target.value, moduleId: ''})} className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-sm bg-white focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <option value="">Seleccionar proyecto</option>
                    {projects.filter(p => p.status === 'activo').map(p => <option key={p.id} value={p.id}>{p.code} — {p.name}</option>)}
                  </select>
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-500 mb-1 block">Módulo</label>
                  <select value={formData.moduleId} onChange={e => setFormData({...formData, moduleId: e.target.value})} className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-sm bg-white focus:outline-none focus:ring-2 focus:ring-blue-500">
                    <option value="">Seleccionar módulo</option>
                    {selectedProject?.modules.map(m => <option key={m.id} value={m.id}>{m.name}</option>)}
                  </select>
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-500 mb-1 block">Autoriza *</label>
                  <input type="text" value={formData.authorizedBy} onChange={e => setFormData({...formData, authorizedBy: e.target.value})} placeholder="Nombre de quien autoriza" className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
                </div>
              </>
            )}
            <div className={formType === 'salida' ? 'sm:col-span-2 lg:col-span-3' : ''}>
              <label className="text-xs font-semibold text-slate-500 mb-1 block">Observaciones</label>
              <input type="text" value={formData.observations} onChange={e => setFormData({...formData, observations: e.target.value})} placeholder="Notas adicionales..." className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
            </div>
          </div>
          <div className="flex justify-end gap-3 mt-6">
            <button onClick={() => setShowForm(false)} className="px-5 py-2.5 border border-slate-200 rounded-xl text-sm font-medium text-slate-600 hover:bg-slate-50 cursor-pointer">Cancelar</button>
            <button onClick={handleSave} className={`px-5 py-2.5 text-white rounded-xl text-sm font-semibold cursor-pointer shadow-lg ${formType === 'entrada' ? 'bg-emerald-600 hover:bg-emerald-700 shadow-emerald-200' : 'bg-red-600 hover:bg-red-700 shadow-red-200'}`}>
              Registrar {formType === 'entrada' ? 'Entrada' : 'Salida'}
            </button>
          </div>
        </div>
      )}

      {/* Delete Confirm */}
      {deleteConfirm && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" onClick={() => setDeleteConfirm(null)}>
          <div className="bg-white rounded-2xl max-w-sm w-full p-6 shadow-2xl" onClick={e => e.stopPropagation()}>
            <div className="w-14 h-14 bg-red-100 rounded-2xl flex items-center justify-center mx-auto mb-4"><Trash2 className="w-7 h-7 text-red-600" /></div>
            <h3 className="font-bold text-lg text-slate-900 text-center mb-2">¿Eliminar movimiento?</h3>
            <p className="text-sm text-slate-500 text-center mb-6">Se eliminará este registro de movimiento permanentemente.</p>
            <div className="flex gap-3">
              <button onClick={() => setDeleteConfirm(null)} className="flex-1 px-4 py-2.5 border border-slate-200 rounded-xl text-sm font-medium text-slate-600 hover:bg-slate-50 cursor-pointer">Cancelar</button>
              <button onClick={() => handleDelete(deleteConfirm)} className="flex-1 px-4 py-2.5 bg-red-600 text-white rounded-xl text-sm font-semibold hover:bg-red-700 cursor-pointer">Eliminar</button>
            </div>
          </div>
        </div>
      )}

      {/* Filters */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 mb-6">
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input type="text" value={search} onChange={e => setSearch(e.target.value)} placeholder="Buscar por artículo, código o usuario..." className="w-full pl-10 pr-4 py-2.5 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
          </div>
          <div className="flex gap-2">
            {['all', 'entrada', 'salida'].map(t => (
              <button key={t} onClick={() => setTypeFilter(t)} className={`px-4 py-2.5 rounded-xl text-sm font-medium transition-colors cursor-pointer ${typeFilter === t ? 'bg-blue-600 text-white shadow-lg shadow-blue-200' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}>
                {t === 'all' ? 'Todos' : t === 'entrada' ? '📥 Entradas' : '📤 Salidas'}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Movements List */}
      <div className="space-y-3">
        {filtered.map(mv => (
          <div key={mv.id} className="bg-white rounded-2xl border border-slate-200 p-5 hover:shadow-md hover:border-slate-300 transition-all">
            <div className="flex items-start gap-4">
              <div className={`w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0 ${mv.type === 'entrada' ? 'bg-emerald-100' : 'bg-red-100'}`}>
                {mv.type === 'entrada' ? <ArrowDownToLine className="w-5 h-5 text-emerald-600" /> : <ArrowUpFromLine className="w-5 h-5 text-red-600" />}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex flex-wrap items-center gap-2 mb-1">
                  <span className="font-semibold text-slate-900">{mv.articleName}</span>
                  <span className="font-mono text-xs bg-slate-100 text-slate-500 px-1.5 py-0.5 rounded">{mv.articleCode}</span>
                  <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${mv.type === 'entrada' ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700'}`}>
                    {mv.type === 'entrada' ? `+${mv.quantity}` : `-${mv.quantity}`} {mv.type.toUpperCase()}
                  </span>
                </div>
                <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-500">
                  <span className="flex items-center gap-1"><User className="w-3 h-3" /> {mv.userName}</span>
                  {mv.projectName && <span className="flex items-center gap-1"><FolderKanban className="w-3 h-3" /> {mv.projectName}</span>}
                  {mv.moduleName && <span className="text-blue-500">/ {mv.moduleName}</span>}
                  <span className="flex items-center gap-1"><FileText className="w-3 h-3" /> {mv.reason}</span>
                </div>
                {mv.observations && <p className="text-xs text-slate-400 mt-1 italic">"{mv.observations}"</p>}
                {mv.authorizedBy && <p className="text-xs text-slate-400 mt-0.5">Autorizó: {mv.authorizedBy}</p>}
              </div>
              <div className="flex items-start gap-2 flex-shrink-0">
                <div className="text-right">
                  <div className="text-sm font-medium text-slate-700">{formatDate(mv.date)}</div>
                  <div className="text-xs text-slate-400">{formatTime(mv.date)}</div>
                </div>
                <button onClick={() => setDeleteConfirm(mv.id)} className="p-2 hover:bg-red-50 rounded-lg cursor-pointer" title="Eliminar">
                  <Trash2 className="w-4 h-4 text-red-400" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {filtered.length === 0 && (
        <div className="py-16 text-center bg-white rounded-2xl border border-slate-200">
          <ArrowRightLeft className="w-12 h-12 text-slate-300 mx-auto mb-3" />
          <p className="text-slate-500 font-medium">No se encontraron movimientos</p>
        </div>
      )}
      <div className="mt-4 text-center text-xs text-slate-400">
        Mostrando {filtered.length} de {movements.length} movimientos
      </div>
    </div>
  );
}
