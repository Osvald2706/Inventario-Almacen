import { Package, AlertTriangle, XCircle, ArrowRightLeft, FolderKanban, ArrowDownToLine, ArrowUpFromLine, TrendingUp, Clock } from 'lucide-react';
import { useData } from '../context/DataContext';

export function Dashboard() {
  const { articles, movements, projects } = useData();

  const totalArticles = articles.length;
  const lowStock = articles.filter(a => a.quantity > 0 && a.quantity <= a.minStock).length;
  const outOfStock = articles.filter(a => a.quantity === 0).length;
  const totalMovements = movements.length;
  const activeProjects = projects.filter(p => p.status === 'activo').length;
  const totalValue = articles.reduce((acc, a) => acc + a.quantity, 0);
  const entriesThisMonth = movements.filter(m => m.type === 'entrada').length;
  const exitsThisMonth = movements.filter(m => m.type === 'salida').length;

  const recentMovements = [...movements].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()).slice(0, 6);
  const lowStockItems = articles.filter(a => a.quantity <= a.minStock);

  // Project movements
  const projectMap: Record<string, { name: string; count: number; items: number }> = {};
  movements.filter(m => m.projectName).forEach(m => {
    if (!projectMap[m.projectId!]) {
      projectMap[m.projectId!] = { name: m.projectName!, count: 0, items: 0 };
    }
    projectMap[m.projectId!].count++;
    projectMap[m.projectId!].items += m.quantity;
  });
  const projectMovements = Object.values(projectMap);

  const statCards = [
    { label: 'Total Artículos', value: totalArticles, icon: <Package className="w-6 h-6" />, color: 'from-blue-500 to-blue-600' },
    { label: 'Stock Bajo', value: lowStock, icon: <AlertTriangle className="w-6 h-6" />, color: 'from-amber-500 to-orange-500' },
    { label: 'Sin Stock', value: outOfStock, icon: <XCircle className="w-6 h-6" />, color: 'from-red-500 to-rose-500', urgent: outOfStock > 0 },
    { label: 'Movimientos', value: totalMovements, icon: <ArrowRightLeft className="w-6 h-6" />, color: 'from-purple-500 to-violet-500' },
    { label: 'Proyectos Activos', value: activeProjects, icon: <FolderKanban className="w-6 h-6" />, color: 'from-emerald-500 to-teal-500' },
    { label: 'Entradas (Mes)', value: entriesThisMonth, icon: <ArrowDownToLine className="w-6 h-6" />, color: 'from-cyan-500 to-sky-500' },
    { label: 'Salidas (Mes)', value: exitsThisMonth, icon: <ArrowUpFromLine className="w-6 h-6" />, color: 'from-pink-500 to-rose-500' },
    { label: 'Unidades Totales', value: totalValue.toLocaleString(), icon: <TrendingUp className="w-6 h-6" />, color: 'from-indigo-500 to-blue-500' },
  ];

  const formatDate = (d: string) => new Date(d).toLocaleDateString('es-MX', { day: '2-digit', month: 'short', year: 'numeric' });
  const formatTime = (d: string) => new Date(d).toLocaleTimeString('es-MX', { hour: '2-digit', minute: '2-digit' });

  return (
    <div>
      <div className="mb-8">
        <h2 className="text-2xl sm:text-3xl font-bold text-slate-900">Dashboard</h2>
        <p className="text-slate-500 mt-1">Resumen general del almacén en tiempo real</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {statCards.map((card, i) => (
          <div key={i} className="bg-white rounded-2xl border border-slate-200 p-5 hover:shadow-lg hover:border-slate-300 transition-all">
            <div className="flex items-start justify-between mb-3">
              <div className={`w-11 h-11 rounded-xl bg-gradient-to-br ${card.color} flex items-center justify-center text-white shadow-lg`}>
                {card.icon}
              </div>
              {card.urgent && (
                <span className="px-2 py-0.5 bg-red-100 text-red-700 text-[10px] font-bold rounded-full animate-pulse">URGENTE</span>
              )}
            </div>
            <div className="text-2xl font-bold text-slate-900">{card.value}</div>
            <div className="text-xs text-slate-500 font-medium mt-0.5">{card.label}</div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200 overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Clock className="w-5 h-5 text-slate-400" />
              <h3 className="font-semibold text-slate-900">Últimos Movimientos</h3>
            </div>
          </div>
          <div className="divide-y divide-slate-50">
            {recentMovements.length === 0 && (
              <div className="px-6 py-8 text-center text-slate-400 text-sm">No hay movimientos registrados</div>
            )}
            {recentMovements.map(mv => (
              <div key={mv.id} className="px-6 py-3.5 flex items-center gap-4 hover:bg-slate-50 transition-colors">
                <div className={`w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 ${mv.type === 'entrada' ? 'bg-emerald-100' : 'bg-red-100'}`}>
                  {mv.type === 'entrada' ? <ArrowDownToLine className="w-4 h-4 text-emerald-600" /> : <ArrowUpFromLine className="w-4 h-4 text-red-600" />}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-medium text-slate-900 truncate">{mv.articleName}</span>
                    <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${mv.type === 'entrada' ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700'}`}>
                      {mv.type === 'entrada' ? `+${mv.quantity}` : `-${mv.quantity}`}
                    </span>
                  </div>
                  <div className="text-xs text-slate-400 truncate">
                    {mv.userName} {mv.projectName ? `→ ${mv.projectName}` : `— ${mv.reason}`}
                  </div>
                </div>
                <div className="text-right flex-shrink-0">
                  <div className="text-xs text-slate-500 font-medium">{formatDate(mv.date)}</div>
                  <div className="text-[10px] text-slate-400">{formatTime(mv.date)}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
          <div className="px-6 py-4 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <FolderKanban className="w-5 h-5 text-slate-400" />
              <h3 className="font-semibold text-slate-900">Salidas por Proyecto</h3>
            </div>
          </div>
          <div className="p-6 space-y-4">
            {projectMovements.length === 0 && <p className="text-sm text-slate-400 text-center">Sin datos</p>}
            {projectMovements.map((p, i) => {
              const colors = ['bg-blue-500', 'bg-emerald-500', 'bg-amber-500', 'bg-purple-500'];
              const maxItems = Math.max(...projectMovements.map(x => x.items));
              return (
                <div key={i}>
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-sm font-medium text-slate-700 truncate">{p.name}</span>
                    <span className="text-xs text-slate-500 font-medium flex-shrink-0 ml-2">{p.items} uds</span>
                  </div>
                  <div className="h-2.5 bg-slate-100 rounded-full overflow-hidden">
                    <div className={`h-full ${colors[i % colors.length]} rounded-full transition-all`} style={{ width: `${(p.items / maxItems) * 100}%` }} />
                  </div>
                  <div className="text-[10px] text-slate-400 mt-1">{p.count} movimientos</div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-100 flex items-center gap-2">
          <AlertTriangle className="w-5 h-5 text-amber-500" />
          <h3 className="font-semibold text-slate-900">Alertas de Stock</h3>
          <span className="ml-auto px-2 py-0.5 bg-amber-100 text-amber-700 text-xs font-bold rounded-full">{lowStockItems.length}</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-slate-50 text-left">
                <th className="px-6 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider">Código</th>
                <th className="px-6 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider">Artículo</th>
                <th className="px-6 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider">Actual</th>
                <th className="px-6 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider">Mínimo</th>
                <th className="px-6 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider">Estado</th>
                <th className="px-6 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider">Ubicación</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {lowStockItems.map(item => (
                <tr key={item.id} className="hover:bg-slate-50 transition-colors">
                  <td className="px-6 py-3"><span className="font-mono text-xs bg-slate-100 text-slate-600 px-2 py-1 rounded">{item.code}</span></td>
                  <td className="px-6 py-3 font-medium text-slate-900">{item.name}</td>
                  <td className="px-6 py-3"><span className={`font-bold ${item.quantity === 0 ? 'text-red-600' : 'text-amber-600'}`}>{item.quantity} {item.unit}</span></td>
                  <td className="px-6 py-3 text-slate-500">{item.minStock} {item.unit}</td>
                  <td className="px-6 py-3">
                    {item.quantity === 0
                      ? <span className="px-2.5 py-1 bg-red-100 text-red-700 text-xs font-bold rounded-full">SIN STOCK</span>
                      : <span className="px-2.5 py-1 bg-amber-100 text-amber-700 text-xs font-bold rounded-full">BAJO</span>}
                  </td>
                  <td className="px-6 py-3 text-slate-500 text-xs">{item.location}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
