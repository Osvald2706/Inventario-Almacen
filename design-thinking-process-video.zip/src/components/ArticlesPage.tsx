import { useState } from 'react';
import { Package, Search, Filter, Plus, MapPin, Tag, X, Eye, Trash2 } from 'lucide-react';
import { useData } from '../context/DataContext';
import type { ArticleCategory, ArticleStatus, UnitOfMeasure } from '../types';

const categoryLabels: Record<ArticleCategory, string> = {
  herramienta: '🔧 Herramienta', material: '🧱 Material', refacción: '⚙️ Refacción',
  consumible: '📦 Consumible', equipo: '🏗️ Equipo', EPP: '🦺 EPP',
  eléctrico: '⚡ Eléctrico', otro: '📋 Otro'
};
const statusColors: Record<ArticleStatus, string> = {
  nuevo: 'bg-emerald-100 text-emerald-700', usado: 'bg-blue-100 text-blue-700',
  dañado: 'bg-red-100 text-red-700', obsoleto: 'bg-slate-200 text-slate-600'
};

export function ArticlesPage() {
  const { articles, addArticle, deleteArticle } = useData();
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [showForm, setShowForm] = useState(false);
  const [selectedArticle, setSelectedArticle] = useState<typeof articles[0] | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);

  // Form state
  const [formData, setFormData] = useState({ code: '', name: '', category: 'herramienta' as ArticleCategory, unit: 'pza' as UnitOfMeasure, quantity: 0, minStock: 0, location: '', status: 'nuevo' as ArticleStatus, observations: '' });

  const filtered = articles.filter(a => {
    const matchSearch = a.name.toLowerCase().includes(search.toLowerCase()) || a.code.toLowerCase().includes(search.toLowerCase());
    const matchCategory = categoryFilter === 'all' || a.category === categoryFilter;
    const matchStatus = statusFilter === 'all' || a.status === statusFilter;
    return matchSearch && matchCategory && matchStatus;
  });

  const handleSave = () => {
    if (!formData.code || !formData.name || !formData.location) return;
    addArticle(formData);
    setFormData({ code: '', name: '', category: 'herramienta', unit: 'pza', quantity: 0, minStock: 0, location: '', status: 'nuevo', observations: '' });
    setShowForm(false);
  };

  const handleDelete = (id: string) => {
    deleteArticle(id);
    setDeleteConfirm(null);
    setSelectedArticle(null);
  };

  return (
    <div>
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
        <div>
          <h2 className="text-2xl sm:text-3xl font-bold text-slate-900">Artículos</h2>
          <p className="text-slate-500 mt-1">Inventario completo del almacén — {articles.length} registros</p>
        </div>
        <button onClick={() => setShowForm(!showForm)} className="flex items-center gap-2 px-5 py-2.5 bg-blue-600 text-white text-sm font-semibold rounded-xl hover:bg-blue-700 transition-colors shadow-lg shadow-blue-200 cursor-pointer">
          <Plus className="w-4 h-4" /> Nuevo Artículo
        </button>
      </div>

      {/* Form Modal */}
      {showForm && (
        <div className="mb-6 bg-white rounded-2xl border border-slate-200 p-6 shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold text-lg text-slate-900">Registrar Nuevo Artículo</h3>
            <button onClick={() => setShowForm(false)} className="p-1 hover:bg-slate-100 rounded-lg cursor-pointer"><X className="w-5 h-5 text-slate-400" /></button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <div><label className="text-xs font-semibold text-slate-500 mb-1 block">Código *</label><input type="text" value={formData.code} onChange={e => setFormData({...formData, code: e.target.value})} placeholder="HER-001" className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" /></div>
            <div><label className="text-xs font-semibold text-slate-500 mb-1 block">Nombre *</label><input type="text" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} placeholder="Nombre del artículo" className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" /></div>
            <div><label className="text-xs font-semibold text-slate-500 mb-1 block">Categoría *</label>
              <select value={formData.category} onChange={e => setFormData({...formData, category: e.target.value as ArticleCategory})} className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-sm bg-white focus:outline-none focus:ring-2 focus:ring-blue-500">
                {Object.entries(categoryLabels).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
              </select>
            </div>
            <div><label className="text-xs font-semibold text-slate-500 mb-1 block">Unidad de Medida</label>
              <select value={formData.unit} onChange={e => setFormData({...formData, unit: e.target.value as UnitOfMeasure})} className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-sm bg-white focus:outline-none focus:ring-2 focus:ring-blue-500">
                <option value="pza">Pieza</option><option value="kg">Kilogramo</option><option value="lt">Litro</option><option value="mt">Metro</option>
                <option value="caja">Caja</option><option value="rollo">Rollo</option><option value="juego">Juego</option><option value="par">Par</option>
                <option value="bolsa">Bolsa</option><option value="galón">Galón</option>
              </select>
            </div>
            <div><label className="text-xs font-semibold text-slate-500 mb-1 block">Cantidad Disponible</label><input type="number" value={formData.quantity} onChange={e => setFormData({...formData, quantity: Number(e.target.value)})} className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" /></div>
            <div><label className="text-xs font-semibold text-slate-500 mb-1 block">Stock Mínimo</label><input type="number" value={formData.minStock} onChange={e => setFormData({...formData, minStock: Number(e.target.value)})} className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" /></div>
            <div><label className="text-xs font-semibold text-slate-500 mb-1 block">Ubicación *</label><input type="text" value={formData.location} onChange={e => setFormData({...formData, location: e.target.value})} placeholder="Rack A-01" className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" /></div>
            <div><label className="text-xs font-semibold text-slate-500 mb-1 block">Estado</label>
              <select value={formData.status} onChange={e => setFormData({...formData, status: e.target.value as ArticleStatus})} className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-sm bg-white focus:outline-none focus:ring-2 focus:ring-blue-500">
                <option value="nuevo">Nuevo</option><option value="usado">Usado</option><option value="dañado">Dañado</option><option value="obsoleto">Obsoleto</option>
              </select>
            </div>
            <div><label className="text-xs font-semibold text-slate-500 mb-1 block">Observaciones</label><input type="text" value={formData.observations} onChange={e => setFormData({...formData, observations: e.target.value})} placeholder="Notas adicionales..." className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" /></div>
          </div>
          <div className="flex justify-end gap-3 mt-6">
            <button onClick={() => setShowForm(false)} className="px-5 py-2.5 border border-slate-200 rounded-xl text-sm font-medium text-slate-600 hover:bg-slate-50 cursor-pointer">Cancelar</button>
            <button onClick={handleSave} className="px-5 py-2.5 bg-blue-600 text-white rounded-xl text-sm font-semibold hover:bg-blue-700 cursor-pointer shadow-lg shadow-blue-200">Guardar Artículo</button>
          </div>
        </div>
      )}

      {/* Filters */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 mb-6">
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input type="text" value={search} onChange={e => setSearch(e.target.value)} placeholder="Buscar por nombre o código..." className="w-full pl-10 pr-4 py-2.5 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500" />
          </div>
          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-slate-400 flex-shrink-0" />
            <select value={categoryFilter} onChange={e => setCategoryFilter(e.target.value)} className="px-3 py-2.5 border border-slate-200 rounded-xl text-sm bg-white focus:outline-none focus:ring-2 focus:ring-blue-500">
              <option value="all">Todas las categorías</option>
              {Object.entries(categoryLabels).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
            </select>
            <select value={statusFilter} onChange={e => setStatusFilter(e.target.value)} className="px-3 py-2.5 border border-slate-200 rounded-xl text-sm bg-white focus:outline-none focus:ring-2 focus:ring-blue-500">
              <option value="all">Todos los estados</option>
              <option value="nuevo">Nuevo</option><option value="usado">Usado</option><option value="dañado">Dañado</option><option value="obsoleto">Obsoleto</option>
            </select>
          </div>
        </div>
      </div>

      {/* Delete Confirm Modal */}
      {deleteConfirm && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" onClick={() => setDeleteConfirm(null)}>
          <div className="bg-white rounded-2xl max-w-sm w-full p-6 shadow-2xl" onClick={e => e.stopPropagation()}>
            <div className="w-14 h-14 bg-red-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <Trash2 className="w-7 h-7 text-red-600" />
            </div>
            <h3 className="font-bold text-lg text-slate-900 text-center mb-2">¿Eliminar artículo?</h3>
            <p className="text-sm text-slate-500 text-center mb-6">Esta acción no se puede deshacer. El artículo será eliminado permanentemente del inventario.</p>
            <div className="flex gap-3">
              <button onClick={() => setDeleteConfirm(null)} className="flex-1 px-4 py-2.5 border border-slate-200 rounded-xl text-sm font-medium text-slate-600 hover:bg-slate-50 cursor-pointer">Cancelar</button>
              <button onClick={() => handleDelete(deleteConfirm)} className="flex-1 px-4 py-2.5 bg-red-600 text-white rounded-xl text-sm font-semibold hover:bg-red-700 cursor-pointer">Eliminar</button>
            </div>
          </div>
        </div>
      )}

      {/* Detail Modal */}
      {selectedArticle && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4" onClick={() => setSelectedArticle(null)}>
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold text-lg text-slate-900">Detalle del Artículo</h3>
              <button onClick={() => setSelectedArticle(null)} className="p-1 hover:bg-slate-100 rounded-lg cursor-pointer"><X className="w-5 h-5 text-slate-400" /></button>
            </div>
            <div className="space-y-3">
              <div className="flex justify-between"><span className="text-sm text-slate-500">Código:</span><span className="font-mono text-sm font-semibold">{selectedArticle.code}</span></div>
              <div className="flex justify-between"><span className="text-sm text-slate-500">Nombre:</span><span className="text-sm font-semibold">{selectedArticle.name}</span></div>
              <div className="flex justify-between"><span className="text-sm text-slate-500">Categoría:</span><span className="text-sm">{categoryLabels[selectedArticle.category]}</span></div>
              <div className="flex justify-between"><span className="text-sm text-slate-500">Cantidad:</span><span className={`text-sm font-bold ${selectedArticle.quantity === 0 ? 'text-red-600' : selectedArticle.quantity <= selectedArticle.minStock ? 'text-amber-600' : 'text-emerald-600'}`}>{selectedArticle.quantity} {selectedArticle.unit}</span></div>
              <div className="flex justify-between"><span className="text-sm text-slate-500">Stock Mínimo:</span><span className="text-sm">{selectedArticle.minStock} {selectedArticle.unit}</span></div>
              <div className="flex justify-between"><span className="text-sm text-slate-500">Ubicación:</span><span className="text-sm">{selectedArticle.location}</span></div>
              <div className="flex justify-between"><span className="text-sm text-slate-500">Estado:</span><span className={`text-xs font-bold px-2 py-1 rounded-full ${statusColors[selectedArticle.status]}`}>{selectedArticle.status.toUpperCase()}</span></div>
              {selectedArticle.observations && <div className="pt-2 border-t border-slate-100"><span className="text-sm text-slate-500 block mb-1">Observaciones:</span><p className="text-sm text-slate-700">{selectedArticle.observations}</p></div>}
            </div>
            <div className="flex gap-3 mt-6 pt-4 border-t border-slate-100">
              <button onClick={() => { setDeleteConfirm(selectedArticle.id); setSelectedArticle(null); }} className="flex items-center gap-2 px-4 py-2.5 bg-red-50 text-red-600 rounded-xl text-sm font-semibold hover:bg-red-100 cursor-pointer">
                <Trash2 className="w-4 h-4" /> Eliminar
              </button>
              <button onClick={() => setSelectedArticle(null)} className="flex-1 px-4 py-2.5 bg-slate-100 text-slate-600 rounded-xl text-sm font-medium hover:bg-slate-200 cursor-pointer">Cerrar</button>
            </div>
          </div>
        </div>
      )}

      {/* Table */}
      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-slate-50 text-left">
                <th className="px-5 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider">Código</th>
                <th className="px-5 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider">Artículo</th>
                <th className="px-5 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider hidden lg:table-cell">Categoría</th>
                <th className="px-5 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider">Cantidad</th>
                <th className="px-5 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider hidden md:table-cell">Ubicación</th>
                <th className="px-5 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider hidden sm:table-cell">Estado</th>
                <th className="px-5 py-3 text-xs font-semibold text-slate-500 uppercase tracking-wider">Acciones</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {filtered.map(article => {
                const isLow = article.quantity > 0 && article.quantity <= article.minStock;
                const isOut = article.quantity === 0;
                return (
                  <tr key={article.id} className={`hover:bg-slate-50 transition-colors ${isOut ? 'bg-red-50/50' : isLow ? 'bg-amber-50/50' : ''}`}>
                    <td className="px-5 py-3"><span className="font-mono text-xs bg-slate-100 text-slate-600 px-2 py-1 rounded">{article.code}</span></td>
                    <td className="px-5 py-3">
                      <div className="font-medium text-slate-900">{article.name}</div>
                      <div className="text-xs text-slate-400 lg:hidden">{categoryLabels[article.category]}</div>
                    </td>
                    <td className="px-5 py-3 hidden lg:table-cell">
                      <span className="flex items-center gap-1.5 text-xs"><Tag className="w-3 h-3 text-slate-400" />{categoryLabels[article.category]}</span>
                    </td>
                    <td className="px-5 py-3">
                      <div className="flex items-center gap-2">
                        <span className={`font-bold ${isOut ? 'text-red-600' : isLow ? 'text-amber-600' : 'text-slate-900'}`}>{article.quantity}</span>
                        <span className="text-xs text-slate-400">{article.unit}</span>
                        {isOut && <span className="text-[9px] font-bold bg-red-100 text-red-700 px-1.5 py-0.5 rounded-full">SIN STOCK</span>}
                        {isLow && !isOut && <span className="text-[9px] font-bold bg-amber-100 text-amber-700 px-1.5 py-0.5 rounded-full">BAJO</span>}
                      </div>
                    </td>
                    <td className="px-5 py-3 hidden md:table-cell">
                      <span className="flex items-center gap-1 text-xs text-slate-500"><MapPin className="w-3 h-3" />{article.location}</span>
                    </td>
                    <td className="px-5 py-3 hidden sm:table-cell">
                      <span className={`text-xs font-bold px-2.5 py-1 rounded-full ${statusColors[article.status]}`}>{article.status.toUpperCase()}</span>
                    </td>
                    <td className="px-5 py-3">
                      <div className="flex items-center gap-1">
                        <button onClick={() => setSelectedArticle(article)} className="p-2 hover:bg-slate-100 rounded-lg cursor-pointer" title="Ver detalle">
                          <Eye className="w-4 h-4 text-slate-400" />
                        </button>
                        <button onClick={() => setDeleteConfirm(article.id)} className="p-2 hover:bg-red-50 rounded-lg cursor-pointer" title="Eliminar">
                          <Trash2 className="w-4 h-4 text-red-400" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        {filtered.length === 0 && (
          <div className="py-12 text-center">
            <Package className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <p className="text-slate-500 font-medium">No se encontraron artículos</p>
          </div>
        )}
        <div className="px-6 py-3 border-t border-slate-100 bg-slate-50 text-xs text-slate-500">
          Mostrando {filtered.length} de {articles.length} artículos
        </div>
      </div>
    </div>
  );
}
